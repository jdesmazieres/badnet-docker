USE badnetteam;

ALTER TABLE  `tnet_event` ADD  `evnt_nbtie` INT NOT NULL DEFAULT  '6';

CREATE TABLE `tnet_umpire` ( `umpi_id` bigint(20) NOT NULL AUTO_INCREMENT,`umpi_cre` datetime NOT NULL,`umpi_pbl` tinyint(4) NOT NULL,`umpi_famname` varchar(30) NOT NULL,`umpi_firstname` varchar(30) NOT NULL,`umpi_gender` tinyint(4) NOT NULL,`umpi_license` varchar(10) NOT NULL,`umpi_numid` bigint(50) NOT NULL COMMENT 'id dans la base origine',`umpi_teamid` bigint(20) NOT NULL,PRIMARY KEY (`umpi_id`),KEY `play_teamid` (`umpi_teamid`),KEY `play_famname` (`umpi_famname`),KEY `play_numid` (`umpi_numid`)) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

ALTER TABLE  `tnet_match` ADD  `mtch_umpireid` BIGINT NOT NULL DEFAULT  '-1', ADD INDEX (  `mtch_umpireid` );

USE badnet;