(function( $ ){
    $.extend({
        ic :{
        settings : {
        'loadMsgDelay' : 200,
        'type' : 'get'
        },

        // Fonction d'affichage du message de chargement
        showPageLoadingMsg : function(aElt) {
            loader=$("<div class='ic-line-msg ic-line-msg-loader ui-corner-all'><span class='ic-icon-loading'></span><h3></h3></div>");
			loader.find( "h3" )
				.text( 'Chargement...' )
				.end()
				.appendTo( aElt )
				.css({
                    top: ( ($(aElt).outerHeight() - $(loader).outerHeight()) / 2 ) + $(aElt).offset().top,
                    left: (($(aElt).outerWidth() - $(loader).outerWidth())/ 2) + $(aElt).offset().left
					});
        },

        // fonction de masquage du message de chargement
        hidePageLoadingMsg : function(aElt) {
			$(aElt).find('.ic-line-msg').remove();
		},
        // Fonction de chargement d'une url
        loadPage : function(aData){
            var vars = aData[0].split('&');
            var params ={};
            for (var i=0;i<vars.length;i++) {
                var pair = vars[i].split("=");
                pair[0] = decodeURIComponent(pair[0]);
                pair[1] = decodeURIComponent(pair[1]);
                params[pair[0]] = pair[1];
            }

            if (params.ic_t){
                var target = $('#' + params.ic_t);
                // Creation de la page cible si elle n'existe pas
                if( !$(target).length ){
                    $('#bp_content').append($('<div id="' + $(target).selector.substr(1) + '"></div>'));
                    target = $($(target).selector);
                }

                // Timeout pour afficher le message de chargement
                var loadMsgDelay = setTimeout(function(){
                    $.ic.showPageLoadingMsg(target);
                 }
                 , $.ic.settings.loadMsgDelay );

                 // Suppression du timer et masquage du message de chargement
                 var hideMsg = function(){

                    // Stop message show timer
                    clearTimeout( loadMsgDelay );

                    // Hide loading message
                    $.ic.hidePageLoadingMsg(target);
                };

                var data = aData[0] + '&' + params.id + '=' + $('#'+params.id).val();

                // Chargement ajax
                $.ajax({
                    url: 'index.php',
                    dataType: "html",
                    type: 'post', //$.ic.settings.type,
                    data: data,
                    success: function( html, textStatus, xhr ) {
                        // Modifier le titre
                        //if(options.title) document.title = options.title;

                        // Vider la cible
                        target.empty();

                        // Afficher le resultat
                        target.append(html);

                        // Cacher le message de chargement
                        hideMsg();
                        if ( $(target).hasClass('ic-page') ){
                            $('.ic-page').hide();
                            $(target).show();
                        }

                        if ( typeof(params.cb) == 'string' ){
                            var idi = '#'+params.id;
                            eval(params.cb + '($("' + idi + '"));');
                        }
                    },
                    error: function( xhr, textStatus, errorThrown ) {
                        // Supprimer le message de chargement
                        hideMsg();

                        //Message d'erreur'
                        var error = $( "<div class='ic-line-msg ic-line-msg-error ui-corner-all'><h3></h3></div>" );
                         error.find( "h3" )
                            .text( 'Erreur chargement' )
                            .end()
                            .appendTo( $(target) )
                            .css({top: ( ($(target).outerHeight() - $(error).outerHeight()) / 2 ) + $(target).offset().top,
                                   left: (($(target).outerWidth() - $(error).outerWidth())/ 2) + $(target).offset().left})
                            .delay( 800 )
                            .fadeOut( 500, function() {
                                $( this ).remove();
                            });
                    }
                });
            }
            else if ( typeof(params.cb) == 'string' ){
                params[params.id] = $('#' + params.id).val();
                $.post('index.php', params, function(a){
                    eval(params.cb + '(a);');
                }, 'json');
                return false;
            }
            else{
                 location = 'index.php?'+aData[0];
                 return false;
            }
        }
       }
    });
})( $ );


(function( $ ){

    var methods = {
    form : function( options ){
         var settings = options || {};
         return this.each(function(){
             $(this).validate({meta:'validate'
              ,errorElement:'p'
              ,errorClass:'ic-input-error'
              ,errorPlacement:function(error, element) {
                   error.appendTo( element.parents('.ic-mandatory') );
                   }
              ,submitHandler:function(aForm){
                $(aForm).find('.ic-btn-valid').button('disable');

                // Timeout pour afficher le message de chargement
                var loadMsgDelay = setTimeout(function(){
                   $.ic.showPageLoadingMsg(aForm);
                }
                , settings.delay || $.ic.settings.loadMsgDelay );

                // Suppression du timer et masquage du message de chargement
                var hideMsg = function(){
                    // Stop message show timer
                    clearTimeout( loadMsgDelay );

                    // Hide loading message
                    $.ic.hidePageLoadingMsg(aForm);
                };

                var md=$(aForm).metadata();
                md['url'] = 'index.php';
                md['error'] = function(a,b,c){
                    $(aForm).find('.ic-btn-valid').removeAttr('disabled');
                    hideMsg();
					var error = $( "<div class='ic-line-msg ic-line-msg-error ui-corner-all'><h3></h3></div>" );
					 error.find( "h3" )
                        .text( settings.error || 'Erreur enregistrement' )
                        .end()
						.appendTo( $(aForm) )
					    .css({top: ( ($(aForm).outerHeight() - $(error).outerHeight()) / 2 ) + $(aForm).offset().top,
                               left: (($(aForm).outerWidth() - $(error).outerWidth())/ 2) + $(aForm).offset().left})
						.delay( 800 )
						.fadeOut( 500, function() {
							$( this ).remove();
						});
                };
                md['success'] = function(txt, status){
                    // re activer le bouton valider
                    $(aForm).find('.ic-btn-valid').button('enable');

                    // Cacher le message de chargement
                    hideMsg();

                    // Vérifier l'erreur et l'afficher
                    var errorMsg = $(txt).find('#icError').text();
                    if ( errorMsg ){
                        var error = $( "<div class='ic-line-msg ic-line-msg-error ui-corner-all'><h3></h3></div>" );
                         error.find( "h3" )
                            .text( errorMsg )
                            .end()
                            .appendTo( $(aForm) )
                            .css({top: ( ($(aForm).outerHeight() - $(error).outerHeight()) / 2 ) + $(aForm).offset().top,
                                   left: (($(aForm).outerWidth() - $(error).outerWidth())/ 2) + $(aForm).offset().left})
                            .delay( 800 )
                            .fadeOut( 500, function() {
                                $( this ).remove();
                            });
                    }
                    else{
                        // afficher le message de fin
                        var acquit = $( "<div class='ic-line-msg ic-line-msg-acquit ui-corner-all'><h3></h3></div>" );
                        acquit.find( "h3" )
                            .text( settings.acquit || 'Enregistrement terminé' )
                            .end()
                            .appendTo( $(aForm) )
                            .css({top: ( ($(aForm).outerHeight() - $(acquit).outerHeight()) / 2 ) + $(aForm).offset().top,
                                   left: (($(aForm).outerWidth() - $(acquit).outerWidth())/ 2) + $(aForm).offset().left})
                            .delay( 800 )
                            .fadeOut( 500, function() {
                                $( this ).remove();
                                if ( settings.dialog) $("#ic-dlg").dialog('close');
                            });
                        if ( settings.ic_t){
                            // Vider la cible
                            $('#' + settings.ic_t).empty();
                            // Afficher le resultat
                            $('#' + settings.ic_t).append(txt);
                        }

                        if ( settings.success) settings.success(txt, status);
                    }
                    return false;
                };
                $(aForm).ajaxSubmit(md);
                return false;
               }
              });
         });
    },

    loadPage : function( options ) {
         return this.each(function(){
            var md = $(this).metadata();
            var id = $(this).attr('id');
            if ( !id){
                var now = new Date();
                id = 'ic_' + now.getTime();
                $(this).attr('id', id);
            }
            //if( $(this).val() ) md[id] = $(this).val();
            md['id'] = id;
            var target = md.ic_t;

            //var data = $(this).attr('href') ? $(this).attr('href').split('?')[1] : $.param(md);
            var data = $.param(md);
            $(this).removeClass('ic-a');
            $(this).removeClass('ic-a-popup');
            data += '&ic_ajax=1';
            if( options && options.event ){
                $(this).bind(options.event, function(){
                    if(options.dialog){
                        var fct=options.buttons || {};

                        fct[options.btnclose] = function(){$(this).dialog("close");};
                        $("#ic-dlg").dialog({'title' : options.title
                        , 'width':  options.width
                        , 'height':  options.height
                        , 'buttons' : fct
                        , modal : true
                        });
                        $("#ic-dlg").dialog('open');
                        target = "#ic-dlg";
                    }
                    if (options.popup){
                        var top = md.top || 10;
                        var left = md.left || 10;
                        var width = md.width || 400;
                        var height = md.height || 300;
                        //var url = $(location).attr('href') + '?bnAction=' + md.bnAction;
                        var url = 'index.php?' + data;
                        var now = new Date();
                        var name = "ic_" + now.getTime();
                        var option = "width=" + width + ",height=" + height + ",top=" + top + ",left=" + left + ",location=no,menubar=no,toolbar=no,scrollbars=no,resizable=yes,status=no";
                        window.open(url, name, option);
                        return false;

                    }
                    if ( History.enabled && !md.nohistory) {
                        History.pushState({0:data}, $(this).html(), "index.php");
                        //$.ic.loadPage({0:data});
                    }
                    else
                        $.ic.loadPage({0:data});
                    return false;
                });
            }
            else {
                //History.pushState({0:data}, '', "index.php");
                $.ic.loadPage({0:data});
                return false;
            }
         });
       }
    };

   $.fn.ic = function( method ) {

    // Method calling logic
    if ( methods[method] ) {
      return methods[ method ].apply( this, Array.prototype.slice.call( arguments, 1 ));
    } else if ( typeof method === 'object' || ! method ) {
      return methods.init.apply( this, arguments );
    } else {
      $.error( 'Method ' +  method + ' does not exist on jQuery.bn' );
    }
    return false;
  };


})( $ );

try{
   (function(window,undefined){
     var History = window.History;
     if ( History.enabled ) {
        // Bind to StateChange Event
        History.Adapter.bind(window,'statechange',function(){
            var State = History.getState();
            var data = State.data;
            $.ic.loadPage(data);
            return false;
        });
     }
     })(window);
}
catch(error){
    var History ={};
    History.enabled=false;
}
