<?php
class icAnchor extends icTag {
    private $_class;
    /**
     *
     * @param string $aId
     * @param string $aUrl
     * @param string $aContent
     * @param string $aClass
     */
    function __construct($aId, $aUrl, $aContent, $aTarget='', $aClass = null) {
        parent::__construct('a', $aId);
        if ( is_int($aUrl) ){
            $this->attribute('href', 'index.php?')
            ->addMetadata('ic_a', $aUrl)
            ->add($aContent);
            if ( !empty($aTarget) ){
                $this->addMetadata('ic_t', $aTarget);
                $this->_class['ic-a'] = 'ic-a';
            }
        }
        else{
            $this->add($aContent)
                ->attribute('href', $aUrl);
        }
        if ( !empty($aClass) ) $this->addClass ($aClass);
    }

    public function addMetadata($aName, $aValue, $aQuote = "'"){
        $href = $this->attribute('href');
        $glue = substr($href, -1) == '?' ? '': '&';
        $this->attribute('href', $href . $glue . $aName.'='.$aValue);
        parent::addMetaData($aName, $aValue, $aQuote);
        return $this;
    }

    public function popup(){
        unset($this->_class['ic-a']);
        $this->_class['ic-a-popup'] = 'ic-a-popup';
        return $this;
    }

    public function dialog($aTitle, $aWidth, $aHeight, $aBtnClose){
        unset($this->_class['ic-a']);
        $this->_class['ic-a-dialog'] = 'ic-a-dialog';
        $this->_optionIc['title'] = $aTitle;
        $this->_optionIc['width'] = $aWidth;
        $this->_optionIc['height'] = $aHeight;
        $this->_optionIc['dialog'] = 1;
        $this->_optionIc['btnclose'] = $aBtnClose;
        $this->_addIcJs();
        return $this;
    }

    private function _addIcJs(){
        $buttons = '{}';
        if ( count($this->_buttons) )
        $buttons = '{' . implode(',', $this->_buttons) . '}';

        $string = '';
        if ( count($this->_optionIc) ){
            $string = "$('#" . $this->id() . "').ic('loadPage', {event:'click', buttons:" . $buttons;
            foreach($this->_optionIc as $option => $value){
                $string .= ',' . $option . ':"' . $value . '"';
                $glue = ',';
            }
            $string .= '});';
        }
        ic::getContent()->addJs('ic'. $this->id(), $string);

    }

    public function cb($aCb){
        $this->attribute('href', $this->attribute('href').'&cb='.$aCb);
        parent::addMetadata('cb', "'$aCb'", '');
        return $this;
    }


    /**
     * @access private
     * @return string
     */
    public function __toString() {
        if (isset($this->_class) ){
            foreach( $this->_class as $class) $this->addClass($class);
            unset($this->_class);
        }
        return parent::__toString();
    }

}
?>