<?php
class icInfo extends icTag {

    /**
     *
     * @param string $aId
     * @param string $aLabel
     * @param string $aContent
     * @param string $aClass
     */
    public function __construct($aId, $aLabel, $aContent, $aClass = null) {
        parent::__construct('p', $aId);
        $this->attribute('class',  'ic-info '.$aClass);
        $this->add(new icTag('span', '', "class='ic-info-label'", $aLabel));
        $this->add(new icTag('span', '', "class='ic-info-value'", $aContent));
    }

}
?>