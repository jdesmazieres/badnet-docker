<?php
class icPage extends icTag  {
    private $_content;
    private $_head;
    private $_body;
    private $_header;
    private $_main;
    private $_footer;
    /**
     *
     * @param string $title
     * @param string $description
     * @param string $auteur
     */
    public function __construct($aTitle, $aDescription, $aAuthor){
         parent::__construct('html');
         $this->_head = $this->add(new icHead($aTitle, $aDescription, $aAuthor), true);
         $this->_content = $this->add(ic::getContent(), true);
         $this->_body = $this->add(new icBody(), true);
         $this->_header = $this->_body->add(new icTag('header'), true);
         $this->_main = $this->_body->add(new icTag('div', 'main'), true);
         $this->_footer = $this->_body->add(new icTag('footer'), true);
         $this->addDiv('ic-dlg');
    }
    /**
     * @access private
     * @return string
     */
    public function __toString(){
        $string = "<!doctype html>\n";
        $string.= parent::__toString();
        /*
        $string .= "<script type='text/javascript'>$(document).ready(function(){\n";
        $string .= "$('#main').ic('loadPage');\n";
        $string .= "$('a').ic('loadPage', {event:'click'});\n";
        $string .= "});\n";
        $string .= "</script>\n";
        */

        return $string;
    }
    /**
     * Gets the Head element (icHead).
     * @return icHead
     */
    public function head() {
        return $this->_head;
    }
    /**
     * Gets the Body element (icBody).
     * @return icBody
     */
    public function body() {
        return $this->_body;
    }
    /**
     * Gets the Body element (icBody).
     * @return icBody
     */
    public function header() {
        return $this->_header;
    }
    /**
     * Gets the Body element (icBody).
     * @return icBody
     */
    public function main() {
        return $this->_main;
    }
    /**
     * Gets the Body element (icBody).
     * @return icBody
     */
    public function footer() {
        return $this->_footer;
    }
    /**
     * Adds a page to the pages collection of HTML Body element (icBody).
     * @param icPage $page
     * @param bool $returnAdded
     * @return icHtml|icPage
     */
    public function addPage($page, $returnAdded=false) {
        $this->body()->addPage($page);
        if ($returnAdded) return $page;
        return $this;
    }
    /**
     * Gets the pages collection in HTML Body (icBody).
     * @return icCollection
     */
    public function pages() {
        return $this->_body()->pages();
    }

    /**
     * @access private
     * @return string
     */
    protected function _openTag() {
        return parent::_openTag() . "\n";
    }

}
?>
