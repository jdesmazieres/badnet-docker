<?php
class icError extends icTag{

    /**
     *
     * @param string $aMsg
     * @param integer $aCode
     */
    public function __construct($aMsg, $aCode=1) {
        parent::__construct('div');
        $this->addP('icError', $aMsg);
    }


}
?>