<?php
class icAttribute {
    private $_name;
    private $_value;
    /**
     *
     * @param string $name
     * @param string $value
     * @param bool $allowBlank
     */
    public function __construct($name, $value=''){
         $this->_name = $name;
         $this->_value = $value;
    }
    /**
     * @return string
     */
    function __toString() {
        $string = '';
        if ($this->value() != '' ) $string = $this->name().'="'.$this->value().'"';
        return $string;
    }
    /**
     * Gets and sets the attribute name property.
     * @param string $value
     * @return string|icAttribute
     */
    public function name(){
        $args = func_get_args();
        if (count($args) == 0) return $this->_name;
        $this->_name = $args[0];
        return $this;
    }
    /**
     * Gets and sets the attribute value property.
     * @param string $value
     * @return string|icAttribute
     */
    public function value(){
        $args = func_get_args();
        if (count($args) == 0) return $this->_value;
        $this->_value = $args[0];
        return $this;
    }
}
?>