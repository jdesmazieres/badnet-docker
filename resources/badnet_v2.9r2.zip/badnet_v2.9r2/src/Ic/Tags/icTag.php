<?php
class icTag {
    private $_tag;
    private $_closed;
    private $_attributes;
    private $_items;

    /**
     *
     * @param string $name
     * @param string $id
     * @param boolean $isClosed
     */
    function __construct($tag='', $aId='', $aClosed=true){
         $this->_tag = $tag;
         $this->_attributes = new icCollection();
         $this->_items = new icCollection();
         if ( !empty($aId) ) $this->attribute('id', $aId);
         $this->_closed = $aClosed;
    }
    /**
     * @access private
     * @return string
     */
    public function __toString() {
        $string = $this->_openTag();
        $string.= $this->items();
        $string.= $this->_closeTag();
        return $string;
    }
    /**
     * Gets a collection of attributes of the tag.
     * @return icCollection
     */
    public function attributes() {
        return $this->_attributes;
    }
    /**
     * Gets and sets the an attribute.
     * @param string $name
     * @param string $value
     * @param bool $returnAttribute
     * @return string|icTag|icAttribute
     */
    public function attribute() {
        $args = func_get_args();
        if (count($args) == 0) return '';
        for ($i = 0; $i < $this->attributes()->size(); $i++) {
            if (is_object($this->attributes()->get($i)) && get_class($this->attributes()->get($i)) == 'icAttribute') {
                if ($this->attributes()->get($i)->name() == $args[0]) {
                    if (count($args) == 1) return $this->attributes()->get($i)->value();
                    $this->attributes()->get($i)->value($args[1]);
                    if (count($args) == 3 && $args[2]) return $this->attributes()->get($i);
                    return $this;
                }
            }
        }
        if (count($args) == 1) return '';
        return $this->addAttribute(new icAttribute($args[0], $args[1]), (count($args) == 3 && $args[2]));
    }

    /**
     * Adds an item.
     * @param mixed $item
     * @param bool $returnItem
     * @return icTag|mixed
     */
    public function action($aAction) {
        $this->addMetadata('ic_a',$aAction);
        $this->addMetadata('ic_ajax', 1);
        return $this;
    }


    /**
     * Gets a collection of items of the tag.
     * @return icCollection
     */
    public function items() {
        return $this->_items;
    }
    /**
     * Adds an item.
     * @param mixed $item
     * @param bool $returnItem
     * @return icTag|mixed
     */
    public function add($aItem, $aReturnItem = false) {
        $this->items()->add($aItem);
        return $aReturnItem ? $aItem : $this;
    }
    /**
     * Gets and sets the HTML tag.
     * @param string $value
     * @return string|icTag
     */
    public function tag() {
        $args = func_get_args();
        if (count($args) == 0) return $this->_tag;
        $this->_tag = $args[0];
        return $this;
    }
    /**
     * Gets and sets the id attribute.
     * @param string $value
     * @return string|icTag
     */
    public function id(){
        $args = func_get_args();
        if (count($args) == 0) return $this->attribute('id');
        $this->attribute('id', $args[0]);
        return $this;
    }
    /**
     * Gets and sets the theme attribute (data-theme="a").
     * @param string $value
     * @return string|icTag
     */
    public function theme() {
        $args = func_get_args();
        if (count($args) == 0) return $this->_theme->value();
        $this->_theme->value($args[0]);
        return $this;
    }
    /**
     * Le contenu de la balise est chargé en ajax
     * @param type $aAction
     */
    public function autoload($aAction){
        $id = $this->id();
        if ( !empty($id) ){
            $this->addMetadata('ic_a', $aAction);
            $this->addMetadata('ic_t', $id);
            ic::getContent()->addJs('id'.$id, "$('#" . $id . "').ic('loadPage');");
        }
        else Ic::log('Id obligatoire pour autoload');
    }
    /**
     * Ajoute une balise a a la balise
     * @return icAnchor
     */
    public function addArea($aName, $aLabel, $aText='', $aMandatory = true){
        return $this->add(new icArea($aName, $aLabel, $aText, $aMandatory), true);
    }
    /**
     * Ajoute une balise a a la balise
     * @return icAnchor
     */
    public function addAnchor($aName, $aAction, $aTarget, $aText='', $aReturn = true){
        return $this->add(new icAnchor($aName, $aAction, $aText, $aTarget), $aReturn);
    }
    /**
     * Adds an attribute.
     * @param icAttribute $attribute
     * @param bool $returnAttribute
     * @return icTag|icAttribute
     */
    public function addAttribute($attribute,$returnAttribute=false) {
        $this->attributes()->add($attribute);
        if ($returnAttribute) return $attribute;
        return $this;
    }
    /**
     * Ajoute un boutton.
     * @param string $aId
     * @param string $aLabel
     * @param integer $aAction
     * @param string $aTarget
     * @param string $aClass
     * @return icButton
     */
    public function addButton($aId, $aLabel='', $aAction=0, $aTarget='', $aClass='') {
        return $this->add(new icButton($aId, $aLabel, $aAction, $aTarget, $aClass), true);
    }
    /**
     * Ajoute un boutton.
     * @param string $aId
     * @param string $aLabel
     * @param integer $aAction
     * @param string $aTarget
     * @param string $aClass
     * @return icButton
     */
    public function addCheckbox($aId, $aLabel='', $aValue=1, $aChecked=false) {
        return $this->add(new icCheckbox($aId, $aLabel, $aValue, $aChecked), true);
    }
    /**
     * Ajoute une classe a la balise
     * @return icTag
     */
    public function addClass($aClass){
        if (empty($aClass) ) return $this;
        $class = $this->attribute('class');
        $glue = empty($class)?'':' ';
        $this->attribute('class', $class . $glue . $aClass);
        return $this;
    }
    /**
     * Ajoute une div a la balise
     * @return icDiv
     */
    public function addDiv($aName='', $aClass='', $aAction=0, $aReturn=true){
        return $this->add(new icDiv($aName, $aClass, $aAction), $aReturn);
    }
    /**
     * Ajoute une zone de saisie
     * @param integer $aAction
     * @param integer $aAction
     * @param integer $aAction
     * @param boolean $aMandatory
     * @return icDiv
     */
    public function addEdit($aName, $aLabel, $aValue='', $aSize=20, $aMandatory=true){
        return $this->add(new icEdit($aName, $aLabel, $aValue, $aSize, $aMandatory), true);
    }
    public function addError($aValue){
        return $this->addP('', $aValue, 'ic-error');
    }
    public function addFieldset($aName='', $aLegend='', $aInline=false, $aClass=''){
        return $this->add(new icFieldset($aName, $aLegend, $aInline, $aClass), true);
    }
    /**
     * Ajoute une form
     * @param string $aId
     * @param integer $aAction
     * @param string $aTarget
     * @return icForm
     */
    public function addForm($aId, $aAction, $aTarget=''){
        return $this->add(new icForm($aId, $aAction, $aTarget), true);
    }
    /**
     * Ajoute une zone de saisie cahce
     * @param string $aName
     * @param string $aValue
     * @return icTag
     */
    public function addHidden($aId, $aValue=''){
        return $this->add(new icTag('input', $aId), true)->attribute('name', $aId)
                ->attribute('type', 'hidden')
                ->attribute('value', $aValue);
    }

    public function addIframe($aName, $aSrc, $aWidth=480, $aHeight=270, $aReturn=true){
        $frame = $this->add(new icTag('iframe', $aName), true)
                ->attribute('src', $aSrc)
                ->attribute('width', $aWidth)
                ->attribute('height', $aHeight)
                ->attribute('frameborder', 0)
                ->attribute('scrolling', 'no')
                ;
        return $aReturn ? $frame:$this;
    }

    /**
     * Ajoute une image la balise
     *
     * @param string $aId
     * @param string $aFile
     * @param string $aAlt
     * @param array $aSize
     * @return icImg
     */
    public function addImage($aId='', $aFile='', $aAlt='', $aSize='', $aReturn=true){
        return $this->add(new icImg($aId, $aFile, $aAlt, $aSize), $aReturn);
    }

    /**
     * Ajoute une line la balise
     * @param string $aName
     * @param boolean $aTitle
     * @return icLine
     */
    public function addLine($aName='', $aTitle=false, $aReturn=true){
        return $this->add(new icLine($aName, $aTitle), $aReturn);
    }

    /**
     * Ajoute une listt a la balise
     * @param string $aName
     * @param string $aClass
     * @return icList
     */
    public function addList($aName='', $aClass='', $aReturn=true){
        return $this->add(new icList($aName, $aClass), $aReturn);
    }

    public function addMap($aName){
        return $this->add(new icMap($aName), true);
    }

    public function addMenu($aName='', $aClass=''){
        return $this->add(new icMenu($aName, $aClass), true);
    }

    /**
     * Ajoute une classe a la balise
     * @return icTag
     */
    public function addMetadata($aName, $aValue, $aQuote = "'"){
        if ( !isset($this->_metadatas) ) $this->_metadatas = new icCollection();
        $this->_metadatas->add(new icMetadata($aName, $aValue, $aQuote));
        return $this;
    }
    /**
     * Ajoute un P
     * @return icP
     */
    public function addP($aName='', $aContent='', $aClass=''){
        return $this->add(new icP($aName, $aContent, $aClass), true);
    }
    /**
     * Ajoute un title a la balise
     * @return icTitle
     */
    public function addTitle($aName, $aLabel, $aLevel=1, $aReturn=true){
        return $this->add(new icTitle($aName, $aLabel, $aLevel), $aReturn);
    }
    /**
     * Ajoute un boutton.
     * @param string $aNameId
     * @param string $aId
     * @param string $aLabel
     * @param string $aValue
     * @param boolean $aChecked
     * @return icButton
     */
    public function addRadio($aName, $aId, $aLabel='', $aValue=1, $aChecked=false) {
        return $this->add(new icRadio($aName, $aId, $aLabel, $aValue, $aChecked));
    }
    /**
     * Ajoute un Span
     * @return icTag
     */
    public function addSpan($aName, $aContent, $aClass='', $aReturn=true){
        $span = $this->add(new icTag('span', $aName), true)->add($aContent)->addClass($aClass);
        return $aReturn ? $span:$this;
    }
    /**
     * Ajoute une select a la balise
     * @return icSelect
     */
    public function addSelect($aName, $aLabel='', $aLov=array(), $aSelect='', $aClass=''){
        return $this->add(new icSelect($aName, $aLabel, $aLov, $aSelect, $aClass), true);
    }

    public function addWarning($aValue){
        return $this->addP('', $aValue, 'ic-warning');
    }


    /**
     * @access private
     * @return string
     */
    protected function _openTag() {
        $string = '';
        if (isset($this->_metadatas) && $this->_metadatas->size() > 0){
            $this->_metadatas->separator(',');
            $string .= $this->_metadatas;
            $this->addClass('{'.$string.'}');
            $this->_metadatas->removeAll();
        }

        $string = '';
        if ( !empty($this->_tag) ){
            $string = '<'.$this->tag();
            if ($this->attributes()->size() > 0) {
                $this->attributes()->separator(' ');
                if (''.$this->attributes()->get(0) != '') $string.=' ';
                $string.= $this->attributes();
            }
            $string.= '>';
        }
        return $string;
    }
    /**
     * @access private
     * @return string
     */
    protected function _closeTag() {
        $string = $this->_closed && !empty($this->_tag) ? '</'.$this->tag().">\n" : "\n";
        return $string;
    }
}
?>