<?php
class icList extends icTag {
    /**
     *
     * @param string $aId
     * @param string $aClass
     */
    public function __construct($aId, $aClass='') {
        parent::__construct('ul', $aId);

        if ( !empty($aClass) ) $this->addClass($aClass);
    }

    public function addItem($aId='', $aContent='', $aReturnItem = false){
        $li = $this->add(new icTag('li', $aId), true)->add($aContent);
        return $aReturnItem ? $li : $this;
    }
}
?>