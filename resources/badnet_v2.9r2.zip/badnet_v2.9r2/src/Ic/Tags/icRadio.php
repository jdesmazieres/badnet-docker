<?php
class icRadio extends icTag {
    private $_label;
    private $_input;

    /**
     *
     * @param string $aId
     * @param string $aUrl
     * @param string $aContent
     * @param string $aClass
     */
    public function __construct($aName, $aId, $aLabel, $aValue='', $aChecked= false) {
        parent::__construct('div', 'div-'.$aId);
        $this->addClass('ic-radio');

        $this->_label = new icTag('label');
        $this->_label->add($aLabel)->attribute('for', $aId);

        $this->_input = new icTag('input', $aId, false);
        $this->_input->attribute('name', $aName)->attribute('type', 'radio')->attribute('value', $aValue);
        $this->_input->addClass('ic-focusable');
        if ($aChecked) $this->_input->attribute('checked', 'checked');

        $this->add($this->_input)->add($this->_label);
    }


}
?>