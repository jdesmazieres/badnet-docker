<?php
class icCheckbox extends icTag {
    private $_label;
    private $_input;

    /**
     *
     * @param string $aId
     * @param string $aUrl
     * @param string $aContent
     * @param string $aClass
     */
    public function __construct($aId, $aLabel, $aValue='', $aChecked= false) {
        parent::__construct('div', 'div-'.$aId);
        $this->attribute('class', 'ic-checkbox');

        $this->_label = new icTag('label');
        $this->_label->add($aLabel)->attribute('for', $aId);

        $this->_input = new icTag('input', $aId, false);
        $this->_input->attribute('name', $aId)->attribute('type', 'checkbox')->attribute('value', $aValue);
        $this->_input->addClass('ic-focusable');
        if ($aChecked) $this->_input->attribute('checked', 'checked');


        $this->add($this->_input)->add($this->_label);
    }

    public function addClass($aClass){
        $this->_input->addClass($aClass);
        return $this;
    }

}
?>