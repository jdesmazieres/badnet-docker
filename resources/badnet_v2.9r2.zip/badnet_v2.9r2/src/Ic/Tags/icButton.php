<?php
class icButton extends icTag {
    private $_optionIc;
    private $_buttons;

    /**
     *
     * @param string $aId
     * @param string $aUrl
     * @param string $aContent
     * @param string $aClass
     */
    function __construct($aId, $aLabel, $aAction, $aTarget, $aClass = null) {
        parent::__construct('input', $aId);
        $this->attribute('value', $aLabel);
        $this->attribute('type', 'button');
        $this->attribute('nohistory', 1);

        if ( $aAction ) $this->addMetadata('ic_a', $aAction);
        if ( !empty($aClass) ) $this->addClass ($aClass);
        if ( !empty($aTarget) ){
            parent::addMetadata('ic_t', $aTarget);
            $this->_optionIc['event'] = 'click';
            $this->_addIcJs();
        }

    }

    /**
     * Gets and sets the type attribute.
     * @param string $value
     * @return string|icTag
     */
    public function type(){
        $args = func_get_args();
        if (count($args) == 0) return $this->attribute('type', 'button');
        $this->attribute('type', $args[0]);
        return $this;
    }

    /**
     * Bouton submit pour les forms
     * @return icButton
     */
    public function submit(){
        $this->type('submit');
        $this->_optionIc = array();
        $this->_addIcJs();
        return $this;
    }

   /**
     * Bouton submit pour les forms
     * @return icButton
     */
    public function submitDlg($aForm, $aLabel){
        $this->_buttons[$aLabel] = '"' . $aLabel . '":function(){$("#' . $aForm . '").submit();}';
        $this->_addIcJs();
        return $this;
    }

    /**
     * Ajout d'une icone
     * @param string $aIcon
     * @param boolean $aRight
     * @return icButton
     */
    public function icon($aIcon, $aRight=false){
        ic::getContent()->addJs('buttonopt'.$this->id(), "$('#" . $this->id() . "').button('option', 'icons', {primary:'ui-icon-" . $aIcon . "'});");
        return $this;
    }

    /**
     * Ouverture de la fentre de dialogue
     * @param string $aTitle
     * @param integer $aWidth
     * @return icButton
     */
    public function dialog($aTitle, $aWidth, $aHeight, $aBtnClose){
        $this->_optionIc['title'] = $aTitle;
        $this->_optionIc['width'] = $aWidth;
        $this->_optionIc['height'] = $aHeight;
        $this->_optionIc['dialog'] = 1;
        $this->_optionIc['btnclose'] = $aBtnClose;
        $this->_addIcJs();
        return $this;
    }

    /**
     * Ouverture de la fentre de dialogue
     * @param string $aTitle
     * @param integer $aWidth
     * @return icButton
     */
    public function button($aLabel, $aJs){
        $this->_buttons[$aLabel] = '"' . $aLabel . '":' . $aJs;
        $this->_addIcJs();
        return $this;
    }

    private function _addIcJs(){
        $buttons = '{}';
        if ( count($this->_buttons) )
        $buttons = '{' . implode(',', $this->_buttons) . '}';

        $string = '';
        if ( count($this->_optionIc) ){
            $string = "$('#" . $this->id() . "').ic('loadPage', {buttons:" . $buttons;
            foreach($this->_optionIc as $option => $value){
                $string .= ',' . $option . ':"' . $value . '"';
                $glue = ',';
            }
            $string .= '});';
        }
        ic::getContent()->addJs('ic'. $this->id(), $string);

    }

}
?>