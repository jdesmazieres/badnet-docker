<?php
class icTitle extends icTag {
    /**
     *
     * @param string $aId
     * @param string $aContent
     * @param integer $aLevel
     */

    public function __construct($aId, $aContent, $aLevel=1) {
        parent::__construct('h'.$aLevel, $aId);
        $this->add($aContent);
    }

}
?>