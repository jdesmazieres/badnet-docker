<?php
class icDiv extends icTag {
    /**
     *
     * @param string $aId
     * @param string $aClass
     * @param integer $aAction
     */
    public function __construct($aId, $aClass='', $aAction=0) {
        parent::__construct('div', $aId);

        if ( !empty($aClass) ) $this->addClass($aClass);
        if ( $aAction ) $this->autoload ($aAction);
    }

}
?>