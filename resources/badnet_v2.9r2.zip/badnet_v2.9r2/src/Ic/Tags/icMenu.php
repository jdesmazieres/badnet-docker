<?php
class icMenu extends icTag {
    /**
     *
     * @param string $aId
     * @param string $aClass
     */
    public function __construct($aId, $aClass='') {
        parent::__construct('ul', $aId);
        if ( !empty($aClass) ) $this->addClass($aClass);
        $this->addClass('ic-menu');
    }

    public function addItem($aId, $aAction, $aTarget, $aText, $select=false){
        $li = $this->add(new icTag('li'), true)
            ->addAnchor($aId, $aAction, $aTarget, $aText)
            ->cb('updateMenu');
        if ($select) $li->addClass('ic-menu-select');
        return $li;
    }
}
?>