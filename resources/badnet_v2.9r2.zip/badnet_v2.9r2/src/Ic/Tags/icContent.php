<?php
class icContent extends icTag {
    private $_js;
    private $_options;

    /**
     *
     */
    function __construct() {
        parent::__construct(null, 'content');
        $project = Ic::getProject();
        $module  = Ic::getModule();

        // Ajout du java script : Fichier du module
        $fileName = "$project/$module/$module.js";
        if ( file_exists(IC_DIR_SRC . $fileName) ){
            $this->add(new icTag('script'), true)
            ->attribute('type', 'text/javascript')
            ->attribute('src', $fileName);
        }

        $this->_js = $this->add(new icTag('script'), true)
            ->attribute('type', 'text/javascript')
            ->add('$(function(){');
        $this->addJs('a', "$('.ic-a').ic('loadPage', {event:'click'});");
        $this->addJs('ap', "$('.ic-a-popup').ic('loadPage', {event:'click', popup:1});");
        //$this->addJs('form', "$('form').jqTransform();");
    }

    /**
     * Ajoute du code js
     * @return icContent
     */
    public function addJs($aName, $aValue){
        $this->_options[$aName] = $aValue;
        return $this;
    }

    /**
     * @access private
     * @return string
     */

    public function __toString() {
        $str = '';
        if (count($this->_options))
            $this->_js->add(implode("\n", $this->_options));
        $this->_js->add("});\n");
        $str = parent::__toString();
        return $str;
    }

}
?>