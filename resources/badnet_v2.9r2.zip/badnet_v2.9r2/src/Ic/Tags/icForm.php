<?php
class icForm extends icTag {
     private $_options;
     private $_ajax = false;


    /**
     *
     * @param string $aId
     * @param string $aClass
     * @param integer $aAction
     */
    public function __construct($aId, $aAction, $aTarget='') {
        parent::__construct('form', $aId);
        $this->_options = array();
        $this->attribute('method', 'post')
                ->attribute('href', 'index.php');
       if ( !empty($aTarget) ){
            $this->_options['target'] = "ic_t:'". $aTarget . "'";
       }
       else{
            $this->addMetadata('dataType', 'json');
       }
       if ( is_int($aAction) ){
            $this->addHidden('ic_a', $aAction);
            $this->addHidden('ic_ajax', true);
            $this->_ajax = true;
       }
        $this->_addIcJs();
    }

    /**
     * Fixe la onciotn javascript a appeler au retour de la soumission
     * @param string aFct
     * @return icForm
     */
    public function submit($aFct){
        $this->_options['success'] = "success:".$aFct;
        $this->_addIcJs();
        return $this;
    }

    /**
     * Force la fermeture de la boit de dialogue après soumissions de la form
     * @return icForm
     */
    public function dialog(){
        $this->_options['dialog'] = 'dialog:1';
        $this->_addIcJs();
        return $this;
    }

    /**
     * Message affiché aprés soumission
     * @param string aMsg
     * @return icForm
     */
    public function acquit($aMsg){
        $this->_options['acquit'] = 'acquit:"' . $aMsg . '"';
        $this->_addIcJs();
        return $this;
    }

    /**
     * Message affiché aprés erreur de soumission
     * @param string aMsg
     * @return icForm
     */
    public function error($aMsg){
        $this->_options['error'] = 'error:"' . $aMsg . '"';
        $this->_addIcJs();
        return $this;
    }

    /**
     * Delai avant d'afficher le message de soumission
     * @param integer aDelay
     * @return icForm
     */
    public function delay($aDelay){
        $this->_options['delay'] = 'delay:' . $aDelay;
        $this->_addIcJs();
        return $this;
    }

    private function _addIcJs(){
        $options = '';
        if ( count($this->_options) ){
            $options = ',{' . implode(',' , $this->_options) . '}';
        }
        $js = "try{ $('#". $this->id() . " .ic-focusable:first').focus();}catch(err){}\n";
        if( $this->_ajax )
            $js .= "$('#". $this->id() . "').ic('form'". $options . ");\n";
        $js .= "$('button, textarea, select, input', $('#" . $this->id() . "')).uniform();\n";

        ic::getContent()->addJs('ic-'. $this->id(), $js);
    }


}
?>