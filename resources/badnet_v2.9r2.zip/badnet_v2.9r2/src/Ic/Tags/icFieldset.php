<?php
class icFieldset extends icTag {
    /**
     *
     * @param string $aId
     * @param string $aClass
     * @param integer $aAction
     */
    public function __construct($aId, $aLabel='', $aInline= false, $aClass='') {
        parent::__construct('fieldset', $aId);

        if ( !empty($aLabel) ) $this->add(new icTag('legend'), true)->add($aLabel);
        if ( !empty($aClass) ) $this->addClass($aClass);
        if ( $aInline ) $this->addClass('ic-inline');
    }

}
?>