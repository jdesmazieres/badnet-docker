<?php
class icLink extends icTag {
    private $_href;
    /**
     *
     * @param string $href
     */
    public function __construct($href='',$media='screen') {
        parent::__construct('link');
        $this->attribute('type', 'text/css');
        $this->attribute('rel', 'stylesheet');
        $this->attribute('media', $media);
        $this->_href = $this->attribute('href', $href, true);
    }
    /**
     * Gets and sets the href attribute.
     * @param string $value
     * @return string|icLink
     */
    public function href(){
        $args = func_get_args();
        if (count($args) == 0) return $this->_href->value();
        $this->_href->value($args[0]);
        return $this;
    }
}
?>