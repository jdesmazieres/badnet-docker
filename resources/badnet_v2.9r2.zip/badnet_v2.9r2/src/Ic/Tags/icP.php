<?php
class icP extends icTag {
    /**
     *
     * @param string $aId
     * @param string $aContent
     * @param string $aClass
     */
    public function __construct($aId, $aContent, $aClass = null) {
        parent::__construct('p', $aId);
        $this->add($aContent);
        if ( !empty($aClass) ) $this->addClass($aClass);
    }

}
?>