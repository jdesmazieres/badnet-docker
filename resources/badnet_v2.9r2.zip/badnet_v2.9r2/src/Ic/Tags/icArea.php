<?php
class icArea extends icTag {
    private $_label;
    private $_input;

    /**
     *
     * @param string $aId
     * @param string $aUrl
     * @param string $aContent
     * @param string $aClass
     */
    public function __construct($aId, $aLabel, $aValue='', $aMandatory = true) {
        parent::__construct('div', 'div-'.$aId);
        $this->addClass('ic-area');

        $this->_label = new icTag('label');
        $this->_label->add($aLabel)->attribute('for', $aId);

        $this->_input = new icTag('textarea', $aId);
        $this->_input->attribute('name', $aId)->add($aValue)->addClass('ic-focusable');
        if ( $aMandatory){
            $this->_input->addClass('{validate:{required:true}}');
            $this->addClass('ic-mandatory');
        }
        else $this->addClass('ic-optional');

        $this->add($this->_label)->add($this->_input);
    }


}
?>