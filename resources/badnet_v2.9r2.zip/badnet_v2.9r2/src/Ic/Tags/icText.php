<?php
class icText {
    private $_text;
    /**
     *
     * @param string $text
     */
    public function __construct($text='') {
        $this->_text = $text;
    }
    /**
     *
     * @return string
     */
    public function __toString(){
        $string = $this->text();
        return $string;
    }
    /**
     *
     * @param string $value
     * @return string|icText
     */
    public function text(){
        $args = func_get_args();
        if (count($args) == 0) return $this->_text;
        $this->_text = $args[0];
        return $this;
    }
}
?>