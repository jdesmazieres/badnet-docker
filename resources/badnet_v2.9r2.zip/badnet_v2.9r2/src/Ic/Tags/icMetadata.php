<?php
class icMetadata {
    private $_name;
    private $_value;
    private $_quote;
    /**
     *
     * @param string $name
     * @param string $value
     * @param bool $allowBlank
     */
    public function __construct($name, $value='', $aQuote="'"){
         $this->_name = $name;
         $this->_value = $value;
         $this->_quote = $aQuote;
    }
    /**
     * @return string
     */
    function __toString() {
        $string = '';
        if ($this->value() != '' ) $string = $this->name() . ":" . $this->_quote . $this->value() . $this->_quote;
        return $string;
    }
    /**
     * Gets and sets the attribute name property.
     * @param string $value
     * @return string|icAttribute
     */
    public function name(){
        $args = func_get_args();
        if (count($args) == 0) return $this->_name;
        $this->_name = $args[0];
        return $this;
    }
    /**
     * Gets and sets the attribute value property.
     * @param string $value
     * @return string|icAttribute
     */
    public function value(){
        $args = func_get_args();
        if (count($args) == 0) return $this->_value;
        $this->_value = $args[0];
        return $this;
    }
 }
?>