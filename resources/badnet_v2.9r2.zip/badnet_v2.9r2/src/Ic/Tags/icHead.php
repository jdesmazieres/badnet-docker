<?php
class icHead extends icTag {
    private $_title;
    private $_css;
    private $_js;
    /**
     *
     * @param string $title
     * @param string $description
     * @param string $auteur
     */
    public function __construct($aTitle, $aDescription, $aAuthor){
        parent::__construct('head');
        $this->add(new icTag('meta', '', false), true)
                ->attribute('charset', 'utf-8');
        /*
        $this->add(new icTag('meta', '', false), true)
                ->attribute('http-equiv', 'X-UA-Compatible')
                ->attribute('content', 'IE=edge,chrome=1');
         *
         */
        $this->_title = new icText($aTitle); $this->add(new icTag('title'), true)->add($this->_title);

        $this->add(new icTag('meta', '', false), true)
                ->attribute('name', 'description')
                ->attribute('content', $aDescription);
        $this->add(new icTag('meta', '', false), true)
                ->attribute('name', 'author')
                ->attribute('content', $aAuthor);
        $this->add(new icTag('meta', '', false), true)
                ->attribute('name', 'viewport')
                ->attribute('content', 'width=device-width, initial-scale=1.0');

        $this->_css = $this->add(new icCollection(), true);
        $this->_js = $this->add(new icCollection(), true);

        $jq_version = '1.8.2';
        $ui_version = '1.9.2';
        $validate_version = '1.9.0';
        $locale = strtolower(Ic::getLocale());

        $this->addCss('Ic/Css/main.css');
        $this->addCss('Ic/Css/normalize.css');
        $this->addCss('Ic/Css/ic.css');

        $this->addJs('Ic/Js/jquery-' . $jq_version . '.min.js');
        $this->addJs('Ic/Js/jquery-ui-' . $ui_version . '.custom.min.js');
        $this->addJs('Ic/Js/jquery.metadata.js');
        $this->addJs('Ic/Js/jquery.form.2.99.js');
        $this->addJs('Ic/Js/jquery.validate.' . $validate_version . '.min.js');
        $this->addJs('Ic/Js/Localization/validate.msg.' . $locale .  '.' . $validate_version . '.js');
        $this->addJs('Ic/Js/highcharts.js');
        $this->addJs('Ic/Js/jquery.selectboxes.min.2.2.4.js');
        $this->addJs('Ic/Js/jquery.uniform.2.1.1.js');
        $this->addJs('Ic/Js/jquery-ui-timepicker-addon.js');
        //$this->addJs('Ic/Js/jquery.scrollTo-1.4.3.1-min.js');
        $this->addJs('Ic/Js/jquery.history.js');
        $this->addJs('Ic/Js/jquery.ic.1.0.1.js');
    }
    /**
     * Gets and sets the title property.
     * @param string $value
     * @return string|icHead
     */
    public function title(){
        $args = func_get_args();
        if (count($args) == 0) return $this->_title->text();
        $this->_title->text($args[0]);
        return $this;
    }
    /**
     * Ajoute un css.
     * @param string $href
     * @param string $media
     * @return string|icHead
     */
    public function addCss($aHref, $aMedia='screen'){
        $this->_css->add(new icTag('link', '', false), true)
                ->attribute('rel', 'stylesheet')
                ->attribute('href', $aHref)
                ->attribute('media', $aMedia);
        return $this;
    }
    /**
     * Ajoute un fichier js
     * @param string $value
     * @return string|icHead
     */
    public function addJs($aSrc){
        $this->_js->add( new icTag('script'), true)
                ->attribute('src', $aSrc);
        return $this;
    }

    public function addFavIcon($aHref){
        $this->_css->add(new icTag('link', '', false), true)
                ->attribute('rel', 'shortcut icon')
                ->attribute('href', $aHref)
                ->attribute('type', 'image/x-icon');
        return $this;
    }

    /**
     * @access private
     * @return string
     */
    protected function _openTag() {
        return parent::_openTag() . "\n";
    }

}
?>
