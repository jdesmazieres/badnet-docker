<?php
class icCollection {
    private $_items;
    /**
     *
     * @param array $items
     * @param string $separator
     * @param string $prefix
     * @param string $suffix
     */
    public function __construct($items=array(), $separator='', $prefix='', $suffix=''){
        if (!is_array($items) && $items != '') $items = array($items);
        if (!is_array($items)) $items = array();
        if (is_array($items)) $this->_items = $items;
        if ( !empty($separator) ) $this->_separator = $separator;
        if ( !empty($prefix) ) $this->_prefix = $prefix;
        if ( !empty($siffix) ) $this->_suffix = $suffix;
    }
    /**
     *
     * @return string
     */
    public function __toString() {
        $string = '';
        if (count($this->_items) > 0) $string .= $this->prefix();
        for($i = 0; $i < count($this->_items); $i++) {
            $str = '' . $this->_items[$i];
            if ($i > 0 && $str != '') $string .= $this->separator();
            $string .= $str;
        }
        if (count($this->_items) > 0) $string .= $this->suffix();
        return $string;
    }
    /**
     * Adds an item.
     * @param mixed $item
     * @return icCollection
     */
    public function add($item, $returnAdded=false) {
        $this->_items[] = $item;
        if ($returnAdded) return $item;
        return $this;
    }
    /**
     * Adds many items from an array.
     * @param array $items
     * @return icCollection
     */
    public function addFromArray($items) {
        if (is_array($items)) for ($i = 0; $i < count($items); $i++) $this->add($items[$i]);
        return $this;
    }
    /**
     * Gets all items.
     * @return array
     */
    public function getAll() {
        return $this->_items;
    }
    /**
     * Gets an item in a position.
     * @param int $index
     * @return mixed
     */
    public function get($index) {
        return $this->_items[$index];
    }
    /**
     * Sets an item in a position.
     * @param int $index
     * @param mixed $item
     * @return icCollection
     */
    public function set($index, $item) {
        $this->_items[$index] = $item;
        return $this;
    }
    /**
     * Removes an item in a position.
     * @param int $index
     * @return icCollection
     */
    public function remove($index) {
        $tmp = array();
        for ($i = 0; $i < count($this->_items); $i++) {
            if ($i != $index) $tmp[] = $this->_items[$i];
        }
        $this->_items = $tmp;
        return $this;
    }
    /**
     * Removes all items.
     * @return icCollection
     */
    public function removeAll() {
        $this->_items = array();
        return $this;
    }
    /**
     * Inserts an item in a position.
     * @param int $index
     * @param mixed $item
     * @return icCollection
     */
    public function insert($index, $item) {
        $tmp = array();
        for ($i = 0; $i < count($this->_items); $i++) {
            if ($i == $index) $tmp[] = $item;
            $tmp[] = $this->_items[$i];
        }
        $this->_items = $tmp;
        return $this;
    }
    /**
     * Gets the collection size.
     * @return int
     */
    public function size() {
        return count($this->_items);
    }
    /**
     * Gets and sets the separator property.
     * @param string $value
     * @return string|icCollection
     */
    public function separator(){
        $args = func_get_args();
        if (count($args) == 0) return empty($this->_separator) ? '' : $this->_separator;
        $this->_separator = $args[0];
        return $this;
    }
    /**
     * Gets and sets the prefix property.
     * @param string $value
     * @return string|icCollection
     */
    public function prefix(){
        $args = func_get_args();
        if (count($args) == 0) return empty($this->_prefix) ? '' : $this->_prefix;
        $this->_prefix = $args[0];
        return $this;
    }
    /**
     * Gets and sets the suffix property.
     * @param string $value
     * @return string|icCollection
     */
    public function suffix(){
        $args = func_get_args();
        if (count($args) == 0) return empty($this->_suffix) ? '' : $this->_suffix;
        $this->_suffix = $args[0];
        return $this;
    }
}
?>