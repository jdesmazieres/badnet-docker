<?php
class icSelect extends icTag {
    private $_label;
    private $_select;

    /**
     *
     * @param string $aId
     * @param string $aLabel
     * @param string $aOptions array value=>text
     * @param string $aSelect value
     * @param string $aClass
     */
    public function __construct($aId, $aLabel, $aOptions=array(), $aSelect='', $aClass='') {
        parent::__construct('div', 'div-'.$aId);
        $this->addClass('ic-select');

        $this->_label = new icTag('label');
        $this->_label->attribute('for', $aId)->add($aLabel);

        $this->_select = new icTag('select', $aId);
        $this->_select->attribute('name', $aId);
        $this->_select->addClass('ic-focusable');

        foreach($aOptions as $value=>$text){
            if ( is_array($text) ){
                $opt = $this->_select->add(new icTag('option'), true)->attribute('value', $text['value'])->add($text['text']);
                foreach( $text['attr'] as $attr) $opt->attribute($attr, $attr);
                if ( $aSelect == $text['value']) $opt->attribute('selected', 'selected');
            }
            else{
                $opt = $this->_select->add(new icTag('option'), true)->attribute('value', $value)->add($text);
                if ( $aSelect == $value) $opt->attribute('selected', 'selected');
            }
        }


        if ( !empty($aClass) ) $this->addClass ($aClass);
        $this->add($this->_label)->add($this->_select)->addP()->attribute('style', 'clear:both;margin:0;');
    }

    /**
     * Fixe l'action sur ls select
     *
     * @param integer $aAction
     * @param string $aTarget
     */
    public function action($aAction, $aTarget=''){
        $this->addMetadata('ic_a', $aAction);
        $this->addMetadata('ic_ajax', 1);
        if ( !empty($aTarget) ) $this->addMetadata('ic_t', $aTarget);
    }

    /**
     * Fixe l'action sur ls select
     *
     * @param integer $aAction
     * @param string $aTarget
     */
    public function addMetaData($aName, $aValue , $aQuote = "'"){
        $this->_select->addMetadata($aName, $aValue, $aQuote);
        return $this;
    }

    public function select(){
        return $this->_select;
    }

    public function change($aAction, $aTarget=''){
        $id = $this->select()->id();
        $string = "$('#" . $id . "').ic('loadPage', {event: 'change'});";
        ic::getContent()->addJs('ic_'. $id, $string);
        $this->_select->addMetadata('ic_a', $aAction);
        $this->_select->addMetadata('nohistory', 1);
        if ( !empty($aTarget) ) $this->_select->addMetadata('ic_t', $aTarget);
        return $this->_select;
    }




}
?>
