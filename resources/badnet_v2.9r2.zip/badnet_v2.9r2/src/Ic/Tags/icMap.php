<?php
class icMap extends icTag {
    /**
     *
     * @param string $aId
     * @param string $aImg
     * @param string $aAlt
     * @param string $aMaxize
     */
    public function __construct($aId) {
        parent::__construct('map', $aId);
        $this->attribute('name', $aId);
    }

    public function addAreashape($aAction, $aTarget, $aCoords, $aType='poly'){
        $area = $this->add(new icTag('area', '', false),  true)
            ->attribute('href', '#')
            ->attribute('alt', 'labas')
            ->attribute('shape', $aType)
            ->attribute('coords', $aCoords)
            ->addMetadata('ic_a', $aAction)
            ->addMetadata('ic_t', $aTarget);
        return $area;
    }
}

?>