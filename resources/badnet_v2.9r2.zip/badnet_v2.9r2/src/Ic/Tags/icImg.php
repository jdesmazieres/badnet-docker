<?php
class icImg extends icTag {
    /**
     *
     * @param string $aId
     * @param string $aImg
     * @param string $aAlt
     * @param string $aMaxize
     */
    public function __construct($aId, $aImg, $aAlt=null, $aMaxize=null) {
        parent::__construct('img', $aId);
        $filename = $aImg;
        $size = false;
        if ( substr($filename, 0, 7) != 'http://' && substr($filename, 0, 8) != 'https://' ){
            if ( ! is_file($filename) ) $filename = '../Themes/Badnetpublic/Badnet/Img/' . $aImg;
            if ( is_file($filename)) $size = getImagesize($filename);
        }
        else $size = getImagesize($filename);
        if ($size){
            $width  = $size[0];
            $height = $size[1];
            // Recalculer la taille de l'image
            if (is_array($aMaxize)){
                $feh = $few = 1;
                if (isset($aMaxize['width'])) $few = $aMaxize['width'] / $size[0];
                if (isset($aMaxize['height'])) $feh = $aMaxize['height'] / $size[1];
                $fe = min(1, $feh, $few);
                $width  = intval($size[0] * $fe);
                $height = intval($size[1] * $fe);
            }
            $this->attribute('width',  $width);
            $this->attribute('height', $height);
            if ( !empty($aAlt) ) $this->attribute('alt', $aAlt);
            $this->attribute('class',  'bn-img');
            $this->attribute('src',  $filename);
        }
    }

    public function addMap($aId){
        $this->attribute('usemap',  '#'.$aId);
    }

    public function __toString() {
        if ($this->attribute('src') != '')
            return parent::__toString();
        else  return '';
    }


    /**
     * Gets and sets the img attribute.
     * @param string $value
     * @return string|icImg
     */
    public function img(){
        $args = func_get_args();
        if (count($args) == 0) return $this->attribute('src');
        $this->attribute('src', $args[0]);
        return $this;
    }
}
?>