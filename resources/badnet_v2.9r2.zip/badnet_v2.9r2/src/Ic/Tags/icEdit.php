<?php
class icEdit extends icTag {
    private $_input;
    private $_dateOptions;
    private $_validate;

    /**
     *
     * @param string $aId
     * @param string $aUrl
     * @param string $aContent
     * @param string $aClass
     */
    public function __construct($aId, $aLabel, $aValue='', $aSize= 20, $aMandatory = true) {
        parent::__construct('div', 'div-'.$aId);
        $this->addClass('ic-edit');

        $label = new icTag('label');
        $label->add($aLabel)->attribute('for', $aId);

        $this->_input = new icTag('input', $aId, false);
        $this->_input->attribute('name', $aId)->attribute('type', 'text')->attribute('value', $aValue)->attribute('size', $aSize);
        $this->_input->addClass('ic-focusable');
        if ( $aMandatory){
            $this->_validate[] = 'required:true';
            $this->addClass('ic-mandatory');
        }
        else $this->addClass('ic-optional');

        $this->add($label)->add($this->_input);
    }

    public function email(){
        $this->_validate[] = 'email:true';
        return $this;
    }
    public function file(){
        $this->_input->attribute('type', 'file');
        return $this;
    }
    public function password(){
        $this->_input->attribute('type', 'password');
        return $this;
    }
    public function disabled(){
        $this->_input->attribute('disabled', 'disabled');
        $this->_input->addClass('ic-disabled');
        return $this;
    }

    public function equalTo($aInput){
        $this->_validate[] = "equalTo:'#". $aInput ."'";
        return $this;
    }

    /**
     * zone de saisie d'une date
     * @param type $aDate
     * @return icEdit
     */
    public function date(){
        //ajout du champ cache mysql
        $id = $this->_input->attribute('size', 10)->id();
        $date = $this->_input->attribute('value');

        if ( !empty($date) ){
            list($y, $m, $d) = explode('-', $date);
            $this->_input->attribute('value', "$d-$m-$y");
        }

        $this->addHidden($id, $date);
        $this->_input->id($id.'-disp');

        $this->_dateOptions[] = 'altField: "#' . $id . '"';
        $this->_dateOptions[] = 'altFormat:"yy-mm-dd"';
        $this->_dateOptions[] = 'dateFormat:"dd-mm-yy"';
        $this->_dateOptions[] = 'changeYear:true';
        $this->_datePicker();
        return $this;
    }

    /**
     * zone de saisie d'une date
     * @param type $aDate
     * @return icEdit
     */
    public function time(){
        $id = $this->_input->attribute('size', 5)->id();
        $time = $this->_input->attribute('value');

        $h = 8;
        $m = 0;
        if ( !empty($time) ){
            list($h, $m) = explode(':', $time);
        }
        $this->_dateOptions[] = 'hour: ' . $h;
        $this->_dateOptions[] = 'minute:' . $m;
        $this->_dateOptions[] = 'stepminute:5';
        $this->_timePicker();
        return $this;
    }
    private function _timePicker(){
        $id = $this->_input->id();

        $script = "$('#" . $id . "').timepicker({";
        $script .= implode("\n,", $this->_dateOptions);
        $script .= "}";
        $script .= ");\n";
        ic::getContent()->addJs('input_'. $id, $script);
    }



    public function dateOption($aName, $aValue){
        $this->_dateOptions[] = $aName.':' . $aValue;
        $this->_datePicker();
        return $this;
    }

    private function _datePicker(){
        $id = $this->_input->id();

        $script = "$('#" . $id . "').datepicker({";
        $script .= implode("\n,", $this->_dateOptions);
        $script .= "}";
        //$script .= ",$.datepicker.regional['$this->_lang']";
        $script .= ");\n";
        $date = $this->_input->attribute('value');
        if ( !empty($date) ){
            list($day, $month, $year) = explode('-', $date);
            $month--;
            $script .= "$('#$id').datepicker('setDate', new Date(" . $year . "," . $month . "," . $day ."));\n";
        }

        ic::getContent()->addJs('input_'. $id, $script);
    }


    /**
     * Champ autocomplete
     *
     * @param integer $aAction
     * @param string $aCallbackSelect
     * @param string $aCallBackSource
     * @return icEdit
     */
    public function autocomplete($aAction, $aCallbackSelect=null, $aTargetAction=0, $aTarget = '', $aCallBackSource = null){
		$id = $this->_input->id();
		$script = "var md = $('#" . $id . "').metadata();\n";
		if ( empty($aCallBackSource) ){
            $script .= "var url='index.php?ic_ajax=1&ic_a=" . $aAction . "';\n";
            $script .= "for(key in md) url += '&' + key + '=' + md[key];\n";
            $script .= '$("#' . $id . '").autocomplete({';
            $script .= 'source: url';
		}
		else{
			$script .= '$("#' . $id . '").autocomplete({';
			$script .= 'source: function(request, response){request.ic_ajax =1;request.ic_a =' . $aAction . ';return '. $aCallBackSource . '(request, response);}';
		}
		$script .= ',minLength: 3';
		$script .= ',delay: 600';
		$script .= ',focus: function(event,ui){return false;}';
		if ( !empty($aCallbackSelect) ) $script .= ',select: function(event,ui){return '. $aCallbackSelect . '(event, ui);}';
		if ( $aTargetAction ) $script .= ',select: function(event,ui){
             ui.item.ic_a='. $aTargetAction . ';
             ui.item.ic_ajax=1;
             $.ic.loadPage($("#' . $aTarget. '"), ui.item);
            }';
		$script .= '});';
		//function(event, ui) {
		//		log(ui.item ? ("Selected: " + ui.item.value + " aka " + ui.item.id) : "Nothing selected, input was " + this.value);
		//	}
        ic::getContent()->addJs('input_'. $id, $script);

      return $this;
  }

     /**
     * @access private
     * @return string
     */
    public function __toString() {
        if (isset($this->_validate) ){
            $class = "{validate:{" . implode(',', $this->_validate) . '}}';
            $this->_input->addClass($class);
            unset($this->_validate);
        }
        return parent::__toString();
    }

}
?>