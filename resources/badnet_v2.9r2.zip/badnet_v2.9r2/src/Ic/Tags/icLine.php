<?php
class icLine extends icTag {
    /**
     *
     * @param string $aId
     * @param boolean $aTitle
     */
    public function __construct($aId='', $aTitle=false, $aClass = null) {
        $class = $aTitle ? 'ic-line-title' : 'ic-line';
        parent::__construct('div', $aId);
        $this->addClass($aClass);
        $this->addClass($class);
    }

    /**
     * Ajoute une cellule
     * @param string $aId
     * @param string $aValue
     * @param string $aClass
     * @return icTag
     */

    public function addCell($aId='', $aValue=null, $aClass = null, $aFixWidth=false, $aReturnCell = true){
        $cell = $this->add(new icCell($aId, $aClass, $aFixWidth), true);

        if (is_null($aValue) ){
            return $cell;
        }
        else{
            $p = $cell->addP('', $aValue);
            return $aReturnCell ? $cell : $p;
        }
    }

}

class icCell extends icTag {
    /**
     *
     * @param string $aId
     * @param boolean $aTitle
     */
    public function __construct($aId='', $aClass = null, $aFixWidth=false) {
        parent::__construct('div', $aId);
        $this->addClass('ic-line-cell');
        $this->addClass( $aFixWidth ? 'ic-fix-width' : 'ic-var-width');
        if ( !empty($aClass) ) $this->addClass($aClass);
    }

    public function addP($aId = null, $aValue=null, $aClass=null){
        if ( !is_null($aValue) && trim($aValue) === '' ) $aValue = "&nbsp;";

        $p = parent::addP('', $aValue, 'ic-line-cell-p');
        $p->addClass($aClass);
        return $p;
    }
}
?>