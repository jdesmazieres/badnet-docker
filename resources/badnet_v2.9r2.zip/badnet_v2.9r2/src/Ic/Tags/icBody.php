<?php
class icBody extends icTag {
    private $_pages;
    /**
     *
     * @param string $id
     * @param array $attributes
     * @param array $items
     * @param array $pages
     */
    public function __construct(){
        parent::__construct('body');
        $this->_pages = $this->add(new icCollection(), true);
    }
    /**
     * Gets the pages collection in HTML Body (icBody).
     * @return icCollection
     */
    public function pages() {
        return $this->_pages;
    }
    /**
     * Adds a page to the pages collection of HTML Body element (icBody).
     * @param icPage $page
     * @param bool $returnAdded
     * @return icBody|icPage
     */
    public function addPage($page, $returnAdded=false) {
        $this->pages()->add($page);
        if ($returnAdded) return $page;
        return $this;
    }

    /**
     * @access private
     * @return string
     */
    protected function _openTag() {
        return parent::_openTag() . "\n";
    }

}
?>