<?php
/*****************************************************************************
 !   $Id$
 ******************************************************************************/
define('IC_DIR_IC',     dirname(__FILE__) . '/');
define('IC_DIR_SRC',    dirname(IC_DIR_IC) . '/');
define('BN_DIR_SRC',    dirname(IC_DIR_IC) . '/');
define('IC_DIR',        dirname(IC_DIR_SRC) . '/');

set_error_handler(array('Ic', 'errorHandler'), E_ALL | E_STRICT);
ini_set('session.gc_maxlifetime', 7200);
session_save_path (        $dir = dirname(__FILE__) . '/../../Temp/Sessions');
session_start();
error_reporting(E_ALL | E_STRICT);

require_once IC_DIR_IC . 'icQuery.php';
require_once IC_DIR_IC . 'icController.php';
//require_once IC_DIR_SRC . 'Jqm/jqmPhp.php';
require_once IC_DIR_IC . 'Tags/icAttribute.php';
require_once IC_DIR_IC . 'Tags/icCollection.php';
require_once IC_DIR_IC . 'Tags/icTag.php';

require_once IC_DIR_IC . 'Tags/icAnchor.php';
require_once IC_DIR_IC . 'Tags/icArea.php';
require_once IC_DIR_IC . 'Tags/icBody.php';
require_once IC_DIR_IC . 'Tags/icButton.php';
require_once IC_DIR_IC . 'Tags/icContent.php';
require_once IC_DIR_IC . 'Tags/icCheckbox.php';
require_once IC_DIR_IC . 'Tags/icDiv.php';
require_once IC_DIR_IC . 'Tags/icEdit.php';
require_once IC_DIR_IC . 'Tags/icFieldset.php';
require_once IC_DIR_IC . 'Tags/icForm.php';
require_once IC_DIR_IC . 'Tags/icError.php';
require_once IC_DIR_IC . 'Tags/icHead.php';
require_once IC_DIR_IC . 'Tags/icImg.php';
require_once IC_DIR_IC . 'Tags/icInfo.php';
require_once IC_DIR_IC . 'Tags/icLine.php';
require_once IC_DIR_IC . 'Tags/icList.php';
require_once IC_DIR_IC . 'Tags/icLink.php';
require_once IC_DIR_IC . 'Tags/icMap.php';
require_once IC_DIR_IC . 'Tags/icMenu.php';
require_once IC_DIR_IC . 'Tags/icMetadata.php';
require_once IC_DIR_IC . 'Tags/icP.php';
require_once IC_DIR_IC . 'Tags/icPage.php';
require_once IC_DIR_IC . 'Tags/icRadio.php';
require_once IC_DIR_IC . 'Tags/icSelect.php';
require_once IC_DIR_IC . 'Tags/icText.php';
require_once IC_DIR_IC . 'Tags/icTitle.php';


class Ic
{
	static private $_pathImg = '';
	static private $_project = '';
	static private $_content = '';
	static private $_module = '';
	static private $_traceMsg  = array(); // Messages de trace
	static private $_userMsg  = array(); // Messages d'erreur pour l'utlisateur
	static private $_dlgTrace  = null; // Dialogue pour afficher les traces
	static private $_startprofile = null;
	static private $_prevprofile = null;
	static private $_startmemory = null;
	static private $_prevmemory = null;

	static public function stripAccent($aStr)
	{
		return strtr($aStr,
 "\xe1\xc1\xe0\xc0\xe2\xc2\xe4\xc4\xe3\xc3\xe5\xc5".
 "\xaa\xe7\xc7\xe9\xc9\xe8\xc8\xea\xca\xeb\xcb\xed".
 "\xcd\xec\xcc\xee\xce\xef\xcf\xf1\xd1\xf3\xd3\xf2".
 "\xd2\xf4\xd4\xf6\xd6\xf5\xd5\x8\xd8\xba\xf0\xfa\xda".
 "\xf9\xd9\xfb\xdb\xfc\xdc\xfd\xdd\xff\xe6\xc6\xdf\xf8\xb0\x27\x2F\x26?*",
 "aAaAaAaAaAaAacCeEeEeEeEiIiIiIiInNoOoOoOoOoOoOoouUuUuUuUyYyaAso  - --");
		//return strtr($aStr,'àáâãäçèéêëìíîïñòóôõöùúûüýÿÀÁÂÃÄÇÈÉÊËÌÍÎÏÑÒÓÔÕÖÙÚÛÜÝ',
//'aaaaaceeeeiiiinooooouuuuyyAAAAACEEEEIIIINOOOOOUUUUY');

	}

    /**
     *
     * @param type $aFct
     * @param type $aPrefix prefixe des functions a supprimer
     * @return type
     */
    static public function autoload($aFct, $aPrefix){
        $fcts = spl_autoload_functions();
        if (is_array($fcts)){
            foreach($fcts as $fct){
                if (substr($fct, 0, strlen($aPrefix)) == $aPrefix)
                spl_autoload_unregister($fct);
            }
        }
        spl_autoload_register($aFct);
        return false;
    }



	static public function nodeValue($aNode, $aElement, $aDefault = null)
	{
        if (empty($aNode) ) return $aDefault;
		$nodeList = $aNode->getElementsByTagName($aElement);
		if ($nodeList != null && $nodeList->length>0)
		{
			return $nodeList->item(0)->nodeValue;
		}
		else return $aDefault;
	}


    static public function profile($aTexte=null){
        if ( empty(self::$_startprofile) ){
            $str = "texte :\t time start\ttime prev\tmem start\tmem prev";
            ic::log($str, 'profile', false);
            $now = Ic::getMicrotime();
            self::$_startprofile = $now;
            self::$_prevprofile = $now;
            $memory = memory_get_usage();
            self::$_startmemory = $memory;
            self::$_prevmemory = $memory;
        }
        else{
            $now = Ic::getMicroTime();
            $str = $aTexte . " : \t";
            $str .= sprintf('%.04f', ($now - self::$_prevprofile));
            $str .= "\t";
            $str .= sprintf('%.04f', ($now - self::$_startprofile));
            $str .= "\t";
            $memory = memory_get_usage();
            $str .= $memory - self::$_prevmemory;
            $str .= "\t";
            $str .= $memory - self::$_startmemory;
            ic::log($str, 'profile', false);
            self::$_prevmemory = $memory;
            self::$_prevprofile = $now;
        }
    }

	/**
	 * Ajoute un message d'erreur destine a etre affiche
	 *
	 * @param string $aMsg  Message a afficher
	 */
	static public function setUserMsg($aMsg) {self::$_userMsg = $aMsg;}

	/**
	 * Renvoi le message utilisateur
	 *
	 * @return unknown
	 */
	static public function getUserMsg() {
		$msg = self::$_userMsg;
		self::$_userMsg = null;
		return $msg;
	}

    /**
     * Renvoi le code captcha utilise
     */
    static public function getCaptcha(){
        return Ic::getValue('phrase');
    }

    /**
     * Renvoi une image captcha
     */
    static public function getCaptchaImage($aColor = '#EEA59B', $aLineRed=0x41, $aLineGreen=0x7C, $aLineBlue=0x51)
    {
        // Set CAPTCHA options (font must exist!)
        require_once IC_DIR_SRC . 'Text/CAPTCHA.php';
        $options = array(
               'font_size' => 24,
               'font_path' => dirname(__FILE__).'/',
               'font_file' => 'alwynregular.ttf',
               'text_color' => $aColor,
               'line_r' => $aLineRed,
               'line_v' => $aLineGreen,
               'line_b' => $aLineBlue
        );
        $text = array('length' => 8,
            'type'   => 'unpronounceable',
            'chars'  => 'numeric');

        // Generate a new Text_CAPTCHA object, Image driver
        $c = Text_CAPTCHA::factory('Image');
        $retval = $c->init(200, 80, $text, $options);
        if (PEAR::isError($retval)) {
            Ic::log($retval);
            exit;
        }

        // Get CAPTCHA secret passphrase
        //$_SESSION['phrase'] = $c->getPhrase();
        Ic::setValue('phrase', $c->getPhrase());

        // Get CAPTCHA image (as PNG)
        $png = $c->getCAPTCHAAsPNG();
        if (PEAR::isError($png)) {
            ic::log($png);
            exit;
        }

        // Nom du fichier de l'image a generer
        $path = realpath('../Temp/Tmp/');
        $filename = tempnam($path.'/', 'bdnet');

        // Purge des anciennes images
        $t = time();
        $h = opendir($path);
        while( $file = readdir($h) ){
            $lastmodif = filemtime($path.'/'.$file);
            if( substr($file, 0, 5 ) == 'bdnet' && ($t-$lastmodif > 3600) ){
                unlink($path.'/'.$file);
            }
        }
        closedir($h);

        // Creation du nouveau code
        $fd = fopen($filename, 'w');
        fwrite($fd, $png);
        fclose($fd);
        chmod($filename, 0777);
        return $filename;
    }

	/**
	 * Return the Project
     * @return icContent
	 */
	static public function getContent()
	{
        if ( empty(self::$_content) ) self::$_content = new icContent( );
		return self::$_content;
	}

	/**
	 * Return the Project
	 */
	static public function getProject()
	{
		return self::$_project;
	}
	/**
	 * Set the project
	 */
	static public function setProject($aProject)
	{
		self::$_project = $aProject;
	}

	/**
	 * Return the module
	 */
	static public function getModule()
	{
		return self::$_module;
	}
	/**
	 * Set the module
	 */
	static public function setModule($aModule)
	{
		self::$_module = $aModule;
	}

	/**
	 * return the time in millisecond
	 */
	static public function getMicroTime()
	{
		list($usec, $sec) = explode(" ",microtime());
		return ((float)$usec + (float)$sec);
	}

	/**
	 * Formate une date iso (yyyy-mm-dd hh:mm:ss) generalement issue de mysql
	 * @param string $aDate	    Date a formater
	 * @param string $aFormat	Format de sortie
	 */
	static public function date($aDate, $aFormat)
	{
		if ($aDate == '0000-00-00 00:00:00' || empty($aDate) ) return '';
		list($y, $m, $d, $h, $mn, $s) =
		sscanf($aDate, "%04u-%02u-%02u %02u:%02u:%02u");
		$timeStamp = mktime ( $h, $mn, $s, $m, $d, $y);
		return date($aFormat, $timeStamp);
	}

	/**
	 * Formate une date iso (yyyy-mm-dd hh:mm:ss) generalement issue de mysql
	 * @param string $aDate	    Date a formater
	 * @param string $aFormat	Format de sortie
	 */
	static public function strdate($aDate, $aFormat)
	{
		list($y, $m, $d, $h, $mn, $s) =
		sscanf($aDate, "%04u-%02u-%02u %02u:%02u:%02u");
		$timeStamp = mktime ( $h, $mn, $s, $m, $d, $y);
		return strftime($aFormat, $timeStamp);
	}

	/**
	 * Fonction de traitement des erreurs PHP
	 * @param 	int		$aErrno		Numero de l'erreur
	 * @param 	string	$aErrstr	Message d'erreur
	 * @param	string	$aErrfile	Fichier d'ou vient l'erreur
	 * @param 	int		$aErrline	Numero de ligne
	 * @return 	true
	 */
	static public function errorHandler($aErrno, $aErrstr, $aErrfile, $aErrline)
	{
		$msg = $aErrfile . '->'. $aErrline .
        	"; PHP " . PHP_VERSION . " (" . PHP_OS . ")";
		Ic::log( $msg . "\n[$aErrno] $aErrstr : ", 'error');
		/* Ne pas executer le gestionnaire interne de PHP */
		return true;
	}

	/**
	 * Fonction de traitement des exception
	 * @param 	mixed	$aE		Execption
	 * @return 	true
	 */
	static function exceptionHandler($aE)
	{
		Ic::log($aE->getMessage());
		Ic::log($aE->getTraceAsString());
		Ic::trace($aE->getTraceAsString());
		$page = Ic::getPage();
		$page->display();
	}

	/**
	 * Renvoi le controller
	 * @return 	string
	 */
	static public function getController()
	{
		static $_controller = null;
		if ( is_null($_controller) )
		{
			$_controller = new icController();
		}
		return $_controller;
	}


    static public function getAuth(){
        static $auth = null;

        if ( empty($auth) ){
            $fileName = Ic::getProject();
            $file = '../Conf/' . $fileName . '.ini';
            $config = parse_ini_file($file, true);
            if( isset($config['auth']) ) $auth = $config['auth'];
        }
        return $auth;
    }

    /**
     * Acces a un parametre du fichier de configuration
     * @param	string		$aName		Nom du parametre
     * @param	string		$aSection	Nom de la section
     * @param 	string		$aFile		Nom du fichier de configuration dans le dossier Conf
     * @return 	string
     */
    static public function getConfigValue($aName, $aSection=null, $aFile = null){

        $fileName = empty($aFile) ? Ic::getProject() : $aFile;
        $file = '../Conf/' . $fileName . '.ini';
        if ( !file_exists($file))
            $file = '../../Conf/' . $fileName . '.ini';

        $config = parse_ini_file($file, true);
        if ( $config == null){
            Ic::log('Fichier  <'. $file . '> inaccessible ', 'Config');
            $backtrace = debug_backtrace();
            Ic::log($backtrace, 'Config');
            return null;
        }
        if ( !isset($aSection) ){
            if ( isset($config[$aName]) ){
                return $config[$aName];
            }
            else{
                Ic::log('Mot clef <' . $aName . '> introuvable dans le fichier ' . $file, 'Config');
                $backtrace = debug_backtrace();
                Ic::log($backtrace, 'Config');
                return null;
            }
        }
        else{
            if ( isset($config[$aSection][$aName]) ){
                return $config[$aSection][$aName];
            }
            else if ( !isset($config[$aSection]) ){
                Ic::log('Section <'. $aSection . '> introuvable dans le fichier ' .$file, 'Config');
                $backtrace = debug_backtrace();
                Ic::log($backtrace, 'Config');
                return null;
            }
            else{
                Ic::log('Mot clef <'. $aName . '> introuvable dans la section <' . $aSection . '> du fichier ' .$file, 'Config');
                $backtrace = debug_backtrace();
                Ic::log($backtrace, 'Config');
                return null;
            }
        }
    }

    /**
     * Renvoi la langue
     * @return 	string
     */
    static public function getLocale($aDefault = 'Fr'){
        $locale = Ic::getValue('locale', $aDefault);
        if ( empty($locale) ) $locale = $aDefault;
        Ic::setValue('locale', $locale);
        return $locale;
    }



    /**
     * Renvoi la mailer pour envoyer un email
     * @return 	Bn_mail
     */
    static public function getMailer(){
        require_once IC_DIR_IC . 'icMail.php';
        return new icMail();
    }

    /**
     * Renvoi la page
     * @return 	Bn_page
     */
    static public function getPage(){
        require_once BN_DIR_BN . 'Page.php';
        return Bn_page::getPage();
    }

    /**
     * Renvoi la langue
     * @return 	string
     */
    static public function getTheme($aDefault=''){
        $theme = Ic::getValue('theme', $aDefault);
        Ic::setValue('theme', $theme);
        return $theme;
    }


    /**
     * Acces a une donnee $_GET, $_POST ou $_SESSION
     * @param	string		$aName		Nom de la donnee
     * @param	string		$aDefault	Valeur par defaut
     * @return 	string
     */
    static public function getValue($aName, $aDefault='', $aHtml=false){
        $res = Ic::getValueHtml($aName, $aDefault);
        if ( is_array($res) ){
            return $res;
        }

        if ( $aHtml){
            return $res;
        }
        else{
            return htmlspecialchars($res);
        }
    }

	/**
	 * Get the attribut with the post or get
	 * @param	string		$aName		Nom de la donnee
	 * @param	string		$aDefault	Valeur par defaut
	 * @return 	string
	 */
	static public function getValueHtml($aName, $aDefault='')
	{
		$value = Ic::_stripslashes_deep($aDefault);

		if (isset($_GET[$aName]))
		{
			$value = Ic::_stripslashes_deep($_GET[$aName]);
		}
		else if (isset($_POST[$aName]))
		{
			$value = Ic::_stripslashes_deep($_POST[$aName]);
		}
		else if (isset($_COOKIE[$aName]))
		{
			$value = $_COOKIE[$aName];
		}
		else if (isset($_SESSION['ic'][$aName]))
		{
			$value = $_SESSION['ic'][$aName];
		}
		return $value;
	}

	/**
	 * Memorisation d'une valeur
	 * @param string 	$aName	Nom de la variable
	 * @param string	$aValue	Contenu de la variable
	 * @return void
	 */
	static public function setValue($aName, $aValue)
	{
		$_SESSION['ic'][$aName] = $aValue;
        return $aValue;
	}

	/**
	 * Memorisation d'une valeur
	 * @param string 	$aName	Nom de la variable
	 * @param string	$aValue	Contenu de la variable
	 * @return void
	 */
	static public function setParam($aName, $aValue)
	{
		$_POST[$aName] = $aValue;
	}

	/**
	 * Supression d'une valeur
	 * @param string	$aName	Nom de la valeur
	 * @return 	void
	 */
	static public function unsetValue($aName)
	{
		$oldValue = empty($_SESSION['ic'][$aName]) ? null: $_SESSION['ic'][$aName];
		unset($_SESSION['ic'][$aName]);
		return $oldValue;
	}

	/**
	 * Ajoute un message dans le fichier de log
	 * @param	string	$aMasg		Message a ajouter
	 * @return 	void
	 */
	static public function log($aMsg, $aFile='Ic', $aFull = true){
        static $loggers = array();

        $dir = '../Temp/Log';
        //if ( !file_exists($dir))
            $dir = dirname(__FILE__) . '/../../Temp/Log';
        $fileName = $dir . '/' . date('Y-m-d-'). $aFile .'.log';
        if ( empty($loggers[$fileName]) ){
            require_once IC_DIR_IC . 'icLog.php';
            $loggers[$fileName] = new icLog($fileName);
        }
        $logger = $loggers[$fileName];
        $str = '';
        if ($aFull){
            $str .= "\n----------------------\n";
            $str .= date('Y-m-d H:i:s') . ' - userId : ' . Ic::getValue('user_id', -1) . ' - userName : ' . Ic::getValue('user_name', ''). ' - userEmail : ' . Ic::getValue('user_email', '') ;
            $backtrace = debug_backtrace();
            $file = @$backtrace[0]['file'];
            $line = @$backtrace[0]['line'];
            $func = @$backtrace[0]['function'];
            $str .= "\nFrom " . $file .'->' . $line;
        }
        $str .= "\n" . Ic::_stringMsg($aMsg);
        $logger->log($str);
        return realpath($fileName);
    }

	/**
	 * Encode une donne au format Json
	 * @param 	mixed	$aVar	Variable a encoder
	 * @return 	string
	 */
	static public function toJson($aVar)
	{
		static $json = null;
		if ( is_null($json) )
		{
			require_once BN_DIR_BN . 'Json.php';
			$json = new Services_JSON();
		}
		return $json->encode($aVar);
	}

	/**
	 * Transforme un objet en chaine de caractere
	 */
	static private function _stringMsg($aMsg)
	{
		if (is_object($aMsg))
		{
			//			if ( method_exists($aMsg, 'toString') )
			//			{
			//				echo "objet avec toString";
			//				$msg = $aMsg->toString();
			//			}
			//			else
			{
				ob_start();
				print_r($aMsg);
				$msg = ob_get_contents();
				ob_end_clean();
			}
		}
		else if ( is_array($aMsg) )
		{
			ob_start();
			print_r($aMsg);
			$msg = ob_get_contents();
			ob_end_clean();
		}
		else
		{
			$msg = $aMsg;
		}
		return $msg;
	}

	static private function _stripslashes_deep($aValue)
	{
		if ( get_magic_quotes_gpc() )
		$aValue = is_array($aValue) ?
		array_map(array('ic' ,'_stripslashes_deep'), $aValue) :
		stripslashes($aValue);

		return $aValue;
	}
}


?>