<?php
/*****************************************************************************
 !   $Id$
******************************************************************************/
require_once IC_DIR_SRC . 'Auth/Auth.php';

/**
 * Fonction appelee apres la connexion
 */
function connectedUser($aLogin, $a){
    // Trace de la connexion et mise a jour du compteur pour l'utilisateur
    Ic::log('Connexion de ' . $aLogin, 'Cnx');
    $table = Ic::getConfigValue('table', 'auth');
    $q = new icQuery($table);
    $field = Ic::getConfigValue('logincol', 'auth');
    $q->addWhere($field . "='" . $aLogin . "'");
    $q->addField('*');
    $user = $q->getRow();
    $q->addValue('user_lastcnx', date('Y-m-d H:i:s'));
    $q->addValue('user_nbcnx', $user['user_nbcnx']+1);
    $q->updateRow();
    ic::setValue('user_id', $user['user_id']);
    ic::setValue('user_name', $user['user_name']);
    ic::setValue('user_type', $user['user_type']);
    ic::setValue('user_ligue', $user['user_ligue']);
    ic::setValue('user_email', $user['user_email']);
    ic::setValue('user_login', $user['user_login']);
    unset($q);

}

/**
 * Fonction appelee apres la deconnexion
 */
function deconnectedUser(){
    ic::log('Déconnexion de ' . Ic::getValue('user_name'), 'Cnx');
    unset($_SESSION['sd']['user_id']);
    unset($_SESSION['sd']['user_name']);
}

/**
 * Gestion de controle des connexions et autorisation d'acces
 */
class icAuth{
    var $_auth   = null;

    /**
     * Verifie la connexion
     */
    function check($aLogin='login', $aPwd='pwd', $aCrypt = true){
        $dsn    = Ic_DB::getDsn(); // . '/' . Bn_Db::getName();
        $prefix = Ic_DB::getPrefix();
        $auth   = Ic::getAuth();

        // The user already login and don't logout
        $fields = explode(',', $auth['fields']);
        $options = array (
            'db_login'      =>  Ic_DB::getUser(),
            'db_pwd'        =>  Ic_DB::getPwd(),
            'dsn' => $dsn,
            'table' => $prefix . $auth['table'],
            'usernamecol'  => $auth['logincol'],
            'passwordcol'  => $auth['pwdcol'],
            'postUsername' => $aLogin,
            'postPassword' => $aPwd,
            'db_fields'    => $fields);

        if ($aCrypt) $options['cryptType'] = $auth['crypt'];
        else $options['cryptType'] = '';
        $this->_auth = new Auth("PDO", $options, '', false);
        $this->_auth->setLoginCallback('connectedUser');
        $this->_auth->setLogoutCallback('deconnectedUser');
        $this->_auth->start();
        if ($this->_auth->checkAuth()){
            return true;
        }
        else{
            return false;
        }
    }

    /**
     * Enregistre une variable de session
     * @param string $aName  nom de la variable
     * @param string $aValue contenu de la variable
     * @return void
     */
    function setValue($aName, $aValue){
        $this->_auth->setAuthData($aName, $aValue);
    }

    /**
     * Retourne la valeur d'une variable de session
     * @param string $aName    nom de la variable
     * @param string $aDefault valeur par defaut
     * @return string Valeur de la variable
     */
    function getValue($aName, $aDefault){
        $value = $this->_auth->getAuthData($aName);
        if ( is_null($value) ){
            return $aDefault;
        }
        return $value;

    }

	/**
	 * Deconnexion
	 *
	 */
	function logout()
	{
		$this->_auth->logout();
	}

}
?>