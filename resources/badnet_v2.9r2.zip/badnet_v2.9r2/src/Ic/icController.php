<?php
/*****************************************************************************
 !   $Id$
******************************************************************************/

class icController{
    private $_defaultPage = -1;
    private $_project = -1;
    private $_projects = array();
    private $_actions = array();

    public function __construct(){
    }

    public function __destruct() {
        //Ic::log( 'Destroying controller' . PHP_EOL, 'profile');
    }

    public function isAjax(){
        return Ic::getValue('ic_ajax', false) && Ic::getValue('ic_a', 0);
    }

	/**
	 * Execution
	 * @return 	string
	 */
    public function run(){
        Ic::setProject('');
        Ic::setModule('');

        // Page a afficher :
        $asked = Ic::getValue('ic_a', $this->project());
        $res=0;
        // Boucle infinie : stop quand le retour de la fonction appelé est vide
        while ( !empty($asked) ){
            // Traitement de l'action au niveau le plus haut : dans le controleur
            foreach ( $this->_actions as $action ){
                if ($asked == $action->getId() ){
                    $res = $action->call();
                }
            }

            // Traitement de l'action au niveau des projets
            $res = $asked;
            foreach ($this->_projects as $project ){
                //Ic::log(sprintf('Action 0x%06X, %d; projet %s', $res, $res, $project->getName()));
                $res = $project->run($res);
                if ( $res != $asked ) break;
            }

            // Action refusee pour insuffisance de droit
            if ( $res == -$asked ){
                $res = $this->_defaultPage;
            }
            // Action non traitee: sortie forcee
            else if ( $res == $asked ){
                if ( $this->isAjax() ) Ic::log(sprintf('Action non traitée 0x%06X, %d', $asked, $asked));
                $res = ($res == $this->_defaultPage) ? 0: $this->_defaultPage;
            }

            // Traiter la nouvelle action
            $asked = $res;
        }
        Ic_Db::closeDbs();
    }

	/**
	 * Ajouter un projet
	 * @param string	$aName	Nom du projet
	 * @param integer	$aMinimum	action minimale du projet
	 * @param integer	$aMaximum	action maximale du projet
	 * @return 	void
	 */
	public function addProject($aName, $aMinimum, $aMaximum, $aAuth=null)
	{
		$this->_projects[] = new icProject($aName, $aMinimum, $aMaximum, $aAuth);
	}

	/**
	 * Ajouter un module
	 * @param string	$aName	Nom du module
	 * @param integer	$aMinimum	action minimale du module
	 * @param integer	$aMaximum	action maximale du module
	 * @return 	void
	 */
	public function addModule($aName, $aMinimum, $aMaximum, $aAuth=null)
	{
		// Tentative d'ajout du module a chaque projet.
		// Le projet decide si le module le concerne ou pas
		$nbProject = 0;
		foreach( $this->_projects as $project)
		{
			$nbProject += $project->addModule($aName, $aMinimum, $aMaximum, $aAuth);
		}
		// Aucun projet n'a retenu le module. C'est pas bon.
		// A reflechir : garde t on un module sans projet ?
		if (!$nbProject)
		{
			Ic::log('Pas de projet pour le module ' . $aName);
			Ic::log("min=$aMinimum:max=$aMaximum");
			exit;
		}
	}

	/**
	 * Definir l'action pour apres login
	 * @param integer	$aValue     Valeur numerique de l'action
	 * @param mixed		$aClasse    Classe a appeler
	 * @param string 	$aMethode	Methode a appeler
	 * @param array  	$aArgs 	    Parametre de la methode
	 * @return 	void
	 */
	public function setLoginAction($aValue, $aClasse, $aMethode, $aArgs=null)
	{
		// Tentative d'ajout de l'action a chaque projet.
		// Le projet decide si l'action le concerne ou pas
		$nbProject = 0;
		foreach( $this->_projects as $project)
		{
			$nbProject += $project->setLoginAction($aValue, $aClasse, $aMethode, $aArgs);
		}
		// Aucun projet n'a retenu l'action.
		if (!$nbProject)
		{
			Ic::log('Pas de projet pour le login ' . $aValue, 'setLoginAction');
			Ic::log($this);
		}
	}

	/**
	 * Definir l'action pour avant  login
	 * @param integer	$aValue     Valeur numerique de l'action
	 * @param mixed		$aClasse    Classe a appeler
	 * @param string 	$aMethode	Methode a appeler
	 * @param array  	$aArgs 	    Parametre de la methode
	 * @return 	void
	 */
	public function setBeforeLoginAction($aValue, $aClasse, $aMethode, $aArgs=null)
	{
		// Tentative d'ajout de l'action a chaque projet.
		// Le projet decide si l'action le concerne ou pas
		$nbProject = 0;
		foreach( $this->_projects as $project)
		{
			$nbProject += $project->setBeforeLoginAction($aValue, $aClasse, $aMethode, $aArgs);
		}
		// Aucun projet n'a retenu l'action.
		if (!$nbProject)
		{
			Ic::log('Pas de projet pour beforeLogin ' . $aValue, 'setLoginAction');
			Ic::log($this);
		}
	}

	/**
	 * Definir l'action pour le logout
	 * @param integer	$aValue     Valeur numerique de l'action
	 * @param mixed		$aClasse    Classe a appeler
	 * @param string 	$aMethode	Methode a appeler
	 * @param array  	$aArgs 	    Parametre de la methode
	 * @return 	void
	 */
	public function setLogoutCallback($aValue, $aClasse, $aMethode, $aArgs=null)
	{
		// Tentative d'ajout de l'action a chaque projet.
		// Le projet decide si l'action le concerne ou pas
		$nbProject = 0;
		foreach( $this->_projects as $project)
		{
			$nbProject += $project->setLogoutAction($aValue, $aClasse, $aMethode, $aArgs);
		}
		// Aucun projet n'a retenu l'action.
		if (!$nbProject)
		{
			Ic::log('Pas de projet pour le logout ' . $aValue, 'setLogoutAction');
			Ic::log($this);
		}
	}

	/**
	* Definir l'action pour le logout
	* @param integer	$aValue     Valeur numerique de l'action
	* @param mixed		$aClasse    Classe a appeler
	* @param string 	$aMethode	Methode a appeler
	* @param array  	$aArgs 	    Parametre de la methode
	* @return 	void
	*/
	public function setLogoutAction($aValue)
	{
		// Tentative d'ajout de l'action a chaque projet.
		// Le projet decide si l'action le concerne ou pas
		$nbProject = 0;
		foreach( $this->_projects as $project){
            $nbProject += $project->setLogoutAction($aValue);
		}
		// Aucun projet n'a retenu l'action.
		if (!$nbProject){
            Ic::log('Pas de projet pour le logout ' . $aValue, 'setLogoutAction');
				Ic::log($this);
		}
	}

	/**
	 * Fixer l'action par defaut
	 * @param integer	$aAction    action par defaut
	 * @return 	void
	 */
	public function project()
	{
        $args = func_get_args();
        if (count($args)){
            $this->_project = $args[0];
        }
        return $this->_project;
	}

    /**
	 * Fixer l'action par defaut
	 * @param integer	$aAction    action par defaut
	 * @return 	void
	 */
    public function page($aDefault){
        return Ic::getValue('ic_a', $aDefault);
    }

	/**
	 * Ajouter une action
	 * @param integer	$aValue     Valeur numerique de l'action
	 * @param mixed	$aClasse    Classe a appeler
	 * @param string 	$aMethode	Methode a appeler
	 * @param array  	$aArgs 	    Parametre de la methode
	 * @return 	void
	 */
	public function addAction($aValue, $aClass, $aMethod, $aArgs=null)
	{
		// Tentative d'ajout de l'action a chaque projet.
		// Le projet decide si l'action le concerne ou pas
		$nbProject = 0;
		foreach( $this->_projects as $project)
		{
			$nbProject += $project->addAction($aValue, $aClass, $aMethod, $aArgs);
		}
		// Aucun projet n'a retenu l'action, elle est retenu au niveau global
		if (!$nbProject)
		{
			$this->_actions[] = new icAction('', '', $aValue, $aClass, $aMethod, $aArgs);
		}
	}

}

class icProject
{
	private $_name;
	private $_minimum;
	private $_maximum;
	private $_isInit  = false;
	private $_modules = array();
	private $_actions = array();
	private $_authLogin = 'txtLogin';
	private $_authPassword = 'txtPwd';
	private $_auth = null;
	private $_actLogin = null;
	private $_actLogout = null;
	private $_actBeforeLogout = null;

	public function __destruct() {
		//Ic::log( 'Destroying: ' . $this->_name . PHP_EOL, 'profile');
	}

	public function __construct($aName, $aMinimum, $aMaximum, $aAuth)
	{
		$this->_name = $aName;
		$this->_minimum = $aMinimum;
		$this->_maximum = $aMaximum;
		$this->_auth = $aAuth;
	}

	/**
	 * Ajouter d'une action  au projet
	 * @return 	string
	 */
	public function addAction($aValue, $aClasse, $aFunction, $aArgs)
	{
		// Verification que l'action concerne le projet
		if ( $aValue < $this->_minimum || $aValue >= $this->_maximum)
		{
			return 0;
		}

		// Tentative d'ajout de l'action a chaque module
		// Le module decide si l'action le concerne ou pas
		$nbModule = 0;
		foreach($this->_modules as $module)
		{
			$nbModule += $module->addAction($aValue, $aClasse, $aFunction, $aArgs);
		}

		// Aucun module ne veut l'action, elle est globale au projet
		if ( !$nbModule )
		{
			$this->_actions[] = new icAction($this->_name, '', $aValue, $aClasse, $aFunction, $aArgs);
		}
		return 1;
	}

	/**
	 * Definir l'action pour le login
	 * @param integer	$aValue     Valeur numerique de l'action
	 * @param mixed		$aClasse    Classe a appeler
	 * @param string 	$aMethode	Methode a appeler
	 * @param array  	$aArgs 	    Parametre de la methode
	 * @return 	void
	 */
	public function setLoginAction($aValue, $aClasse, $aMethode, $aArgs)
	{
		// Verification que l'action concerne le projet
		if ( $aValue < $this->_minimum || $aValue >= $this->_maximum)
		{
			return 0;
		}
		$this->_actLogin = new Action($this->_name, '', $aValue, $aClasse, $aMethode, $aArgs);
		return 1;
	}

	/**
	 * Definir l'action pour avant login
	 * @param integer	$aValue     Valeur numerique de l'action
	 * @param mixed		$aClasse    Classe a appeler
	 * @param string 	$aMethode	Methode a appeler
	 * @param array  	$aArgs 	    Parametre de la methode
	 * @return 	void
	 */
	public function setBeforeLoginAction($aValue, $aClasse, $aMethode, $aArgs)
	{
		// Verification que l'action concerne le projet
		if ( $aValue < $this->_minimum || $aValue >= $this->_maximum)
		{
			return 0;
		}
		$this->_actBeforeLogin = new action($this->_name, '', $aValue, $aClasse, $aMethode, $aArgs);
		return 1;
	}

	/**
	 * Definir l'action pour le login
	 * @param integer	$aValue     Valeur numerique de l'action
	 * @param mixed		$aClasse    Classe a appeler
	 * @param string 	$aMethode	Methode a appeler
	 * @param array  	$aArgs 	    Parametre de la methode
	 * @return 	void
	 */
	public function setLogoutCallback($aValue, $aClasse, $aMethode, $aArgs)
	{
		// Verification que l'action concerne le projet
		if ( $aValue < $this->_minimum || $aValue >= $this->_maximum)
		{
			return 0;
		}
		$this->_logoutCallback = new action($this->_name, '', $aValue, $aClasse, $aMethode, $aArgs);
		return 1;
	}

	/**
	* Definir l'action pour le logout
	* @param integer	$aValue     Valeur numerique de l'action
	* @return 	void
	*/
	public function setLogoutAction($aValue)
	{
		// Verification que l'action concerne le projet
		if ( $aValue < $this->_minimum || $aValue >= $this->_maximum)
		{
			return 0;
		}
		$this->_actLogout = $aValue;
		return 1;
	}

    /**
     * Lance l'action du projet ou du module
     * @return 	string
     */
    public function run($aAction){
        Ic::setProject($this->_name);
        $asked = $aAction;
        // Verification que l'action concerne le projet
        if ( $asked < $this->_minimum || $asked >= $this->_maximum){
            return $aAction;
        }

        // Initialisation du projet
        if (! $this->_isInit ){
            $this->_isInit = true;
            $file = IC_DIR_SRC . $this->_name . '/' . $this->_name . '.inc';
            if ( file_exists($file)) require_once $file;
            $file = IC_DIR_SRC . $this->_name . '/' . $this->_name . '.php';
            if ( file_exists($file)) require_once $file;
            $a = new $this->_name($aAction);
        }

        // Verifier la deconnexion
        if ( $this->_actLogout == $asked ){
            require_once BN_DIR_BN . 'Auth.php';
            $auth = new Bn_Auth();
            $auth->check($this->_authLogin, $this->_authPassword);
            $auth->logout();
            unset($_SESSION['bn']);
            if ( !empty($this->_logoutCallback) ) return $this->_logoutCallBack->call();
            return -$asked;
        }

        // Verifier l'authentification
        if ( !empty($this->_auth) ){
            // Appel de l'action  beforeLogin
            if ( !empty($this->_actBeforeLogin) ){
                //$this->_actBeforeLogin->call();
            }

            // Controle du login
            require_once BN_DIR_BN . 'Auth.php';
            $auth = new Bn_Auth();
            if ( !$auth->check($this->_authLogin, $this->_authPassword) ){
                Ic::log('erreur login : ' . Ic::getValue($this->_authLogin) . ',' . Ic::getValue($this->_authPassword));
                return -$aAction;
            }

            // login ok, verifier les droits
            if ( $this->_auth != '*' ){
                $profil = Ic::getValue('user_type');
                $profils = explode(';', $this->_auth);
                if ( ! in_array($profil, $profils) ){
                    Ic::log('erreur login : ' . Ic::getValue($this->_authLogin) . ',' . Ic::getValue($this->_authPassword));
                    return -$aAction;
                }
            }

            // Appel du callback d'apres login
            if ( !empty($this->_actLogin) && $asked == $this->_actLogin->getId() ){
                return $this->_actLogin->call();
            }
        }

        // Rechercher l'action au niveau du projet
        foreach ($this->_actions as $action){
            if ( $action->getId() == $asked ){
                return $action->call();
            }
        }

        // Pas d'action au niveau projet, recherche dans les modules
        foreach ($this->_modules as $module){
            //Ic::log(sprintf('Module 0x%06X, %d; projet %s', $asked, $asked, $module->getName()));
            $asked = $module->run($asked);
            if (empty($asked)) break;
        }

        if ( $asked < 0 ){
            $str = sprintf('Projet %s : action non trouvée %d; 0x%04X <br>',  $this->_name, $aAction, $aAction );
            Ic::log($str);
        }
        return $asked;
    }


	/**
	 * Ajouter un module au projet
	 * @return 	string
	 */
	public function addModule($aName, $aMinimum, $aMaximum, $aAuth=null)
	{
		// Verification que le module concerne le projet
		if ( $aMinimum < $this->_minimum || $aMaximum >= $this->_maximum)
		{
			return 0;
		}
		$this->_modules[] = new icModule($this->_name, $aName, $aMinimum, $aMaximum, $aAuth);
		return 1;
	}

	public function getName()
	{
		return $this->_name;
	}
}

class icModule{
	private $_project;
	private $_name;
	private $_minimum;
	private $_maximum;
	private $_auth = null;
	private $_isInit  = false;
	private $_actions = array();

	public function __construct($aProject, $aName, $aMinimum, $aMaximum, $aAuth=null){
		$this->_project = $aProject;
		$this->_name = $aName;
		$this->_minimum = $aMinimum;
		$this->_maximum = $aMaximum;
		$this->_auth = $aAuth;
	}

	public function getName(){
		return $this->_name;
	}

	/**
	 * Ajouter une action au module
	 * @return 	string
	 */
	public function addAction($aValue, $aClass, $aFunction, $aArgs){
		// verification que l'action concerne le module
		if ( $aValue < $this->_minimum || $aValue >= $this->_maximum){
			return 0;
		}
		// Enregistrement de l'action
		else{
			$this->_actions[] = new icAction($this->_project, $this->_name, $aValue, $aClass, $aFunction, $aArgs);
			return 1;
		}
	}

	/**
	 * Lance l'action du module
	 * @return 	string
	 */
	public function run($aAction){
		Ic::setModule($this->_name);
		$asked = $aAction;
		// Verification que l'action concerne le module
		if ( $asked < $this->_minimum || $asked >= $this->_maximum){
			return $aAction;
		}

		// Verification de l'authentification
		if ( !empty($this->_auth) ){
			// @todo : voir login et lougout callback; les champs de login en dur txtLogin et txtPwd
			// Controle du login
			require_once BN_DIR_BN . 'Auth.php';
			$auth = new Bn_Auth();
			if ( !$auth->check('txtLogin', 'txtPwd' ) )
			{
				$auth->logout();
				unset($_SESSION['bn']);
				Ic::log('erreur login : ' . Ic::getValue('txtLogin') . ',' . Ic::getValue('txtPwd'));
				return -$aAction;
			}

			// login ok, verifier les droits
			if ( $this->_auth != '*' )
			{
				$profil = Ic::getValue('user_type');
				$profils = explode(';', $this->_auth);
				if ( ! in_array($profil, $profils) )
				{
					Ic::log('erreur login : ' . Ic::getValue($this->_authLogin) . ',' . Ic::getValue($this->_authPassword));
					return -$aAction;
				}
			}
		}


		// Initialisation du module
		if (! $this->_isInit ){
			$this->_isInit = true;
			require_once IC_DIR_SRC . $this->_project .'/' . $this->_name . '/' . $this->_name . '.inc';
			require_once IC_DIR_SRC . $this->_project .'/' . $this->_name . '/' . $this->_name . '.php';
			$a = new $this->_name($aAction);
		}

        // Rechercher de l'action au niveau du module
        foreach ($this->_actions as $action){
            if ( $action->getId() == $asked ){
                $res = $action->call();
                return $res;
            }
        }

        Ic::log('Module ' . $this->_name . ': action non trouvée ' . $aAction );
        return -2;
    }
}

class icAction
{
	private $_id;
	private $_class;
	private $_method;
	private $_args;
	private $_project;
	private $_module;

	public function __construct($aProject, $aModule, $aId, $aClass, $aMethod, $aArgs)
	{
		$this->_id = $aId;
		$this->_class = $aClass;
		$this->_method = $aMethod;
		$this->_project = $aProject;
		$this->_module = $aModule;
		if ( is_array($aArgs) )
		{
			$this->_args = $aArgs;
		}
		else
		{
			$this->_args[] = $aArgs;
		}

	}
	public function getId()
	{
		return $this->_id;
	}
	public function call()
	{
		if ( method_exists($this->_class, $this->_method) )
		{
			// enregistrement de l'action pour les stats
			if (Ic::getConfigValue('stats', 'params'))
			{
				$q = new Ic_query('stats', '_stats');
				if ($q)
				{
					$q->setFields('stat_nb');
					$q->addWhere('stat_action =' . $this->_id);
					$q->addWhere("stat_day ='" . date('Y-m-d') . "'");

					$nb = $q->getFirst(); $nb++;
					$q->addValue('stat_nb', $nb);
					$q->addValue('stat_action', $this->_id);
					$q->addValue('stat_module', get_class($this->_class));
					$q->addValue('stat_function', $this->_method);
					$q->addValue('stat_day', date('Y-m-d'));
					$q->replaceRow();
					unset($q);
				}
			}

			// Fichier de langue
			$locale = Ic::getLocale();
			$project = $this->_project;
			$module = $this->_module;
			$fileLocale = IC_DIR_SRC . "$project/Locale/$locale/" . $project . '.inc';
			if ( file_exists($fileLocale) )	require_once $fileLocale;

			$fileLocale = IC_DIR_SRC . "$project/Locale/$locale/" . $module . '.inc';
			if ( file_exists($fileLocale) )	require_once $fileLocale;

			$fileLocale = IC_DIR_SRC . "$project/Locale/$locale/" . 'Commun.inc';
			if ( file_exists($fileLocale) )	require_once $fileLocale;

			return call_user_func_array( array($this->_class, $this->_method), $this->_args);
		}
		else
		{
			Ic::log('function inconnue ' . $this->_method );
			return -2;
		}
	}
}
?>