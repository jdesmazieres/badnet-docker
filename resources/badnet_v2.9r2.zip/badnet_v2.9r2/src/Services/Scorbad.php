<?php
/*****************************************************************************
 !   $Id$
******************************************************************************/
error_reporting(E_ALL);
require_once '../Ic/ic.php';
require_once '../Ic/icQuery.php';

define('CEVENT_TYPE_INDIVIDUAL',  70);
define('CEVENT_TYPE_IC',          71);
define("CMATCH_DISCI_MS",      1);
define("CMATCH_DISCI_LS",      2);
define("CMATCH_DISCI_WS",      2);
define("CMATCH_DISCI_MD",      3);
define("CMATCH_DISCI_LD",      4);
define("CMATCH_DISCI_WD",      4);
define("CMATCH_DISCI_MX",      5);
define("CMATCH_DISCI_XD",      5);
define("CMATCH_DISCI_AS",      6);
define("CMATCH_DISCI_AD",      7);
define("CMATCH_STATUS_INCOMPLET", 30);
define("CMATCH_STATUS_BUSY",    31);// Joueur indisponible
define("CMATCH_STATUS_REST",    32);// Temps de repos
define("CMATCH_STATUS_READY",   33);// Pret a jouer
define("CMATCH_STATUS_LIVE",    34);// En cours
define("CMATCH_STATUS_ENDED",   35);// Termine
define("CMATCH_STATUS_CLOSED",  36);// Valide
define("CMATCH_STATUS_SEND",    37);// Transmis(ffba)
define("CMATCH_RESULT_NOPLAY",    80);
define("CMATCH_RESULT_WIN",       81);
define("CMATCH_RESULT_WINAB",     82);
define("CMATCH_RESULT_WINWO",     83);
define("CMATCH_RESULT_LOOSE",     84);
define("CMATCH_RESULT_LOOSEAB",   85);
define("CMATCH_RESULT_LOOSEWO",   86);
define("CMATCH_PAIR_TOP",      130);
define("CMATCH_PAIR_BOTTOM",   131);
define('CROUND_TYPE_GROUP',    280);
define('CROUND_TYPE_QUALIF'	,  281);
define('CROUND_TYPE_MAINDRAW', 282);
define('CROUND_TYPE_THIRD',    283);
define('CROUND_TYPE_CONSOL',   284);
define('CROUND_TYPE_PLATEAU',  285);
define('CROUND_TYPE_RONDE',    286);
define('CROUND_TYPE_AR',       287);
define('CROUND_TYPE_PROGRES',  288);
define("CTIE_STAGE_WINNER",    260);
define("CTIE_STAGE_FINAL",     261);
define("CTIE_STAGE_SEMI",      262);
define("CTIE_STAGE_QUATER",    263);
define("CTIE_STAGE_HEIGHT",    264);
define("CTIE_STAGE_16",        265);
define("CTIE_STAGE_32",        266);
define("CTIE_STAGE_64",        267);
define("CTIE_STAGE_128",       268);
define("CTIE_STAGE_256",       269);
define("CTIE_STAGE_GROUP",     299);

set_error_handler('errorHandler', E_ALL);
function errorHandler($aErrno, $aErrstr, $aErrfile, $aErrline){
	$msg = "Ligne $aErrline; fichier $aErrfile".
        	"; PHP " . PHP_VERSION . " (" . PHP_OS . ")";
	ic::log("[$aErrno] $aErrstr : $msg", 'svc');

	// Ne pas executer le gestionnaire interne de PHP
	return true;
}

class Player{
	/** @var int identifiant */
	public $id;

	/** @var int Genre */
	public $gender;

	/** @var string Nom de famille */
	public $familyname;

	/** @var string Prenom*/
	public $firstname;

	/** @var string Numero de licence */
	public $license;

	/** @var string Noc */
	public $noc;

	/** @var string Equipe */
	public $team;

	/** @var string Classement */
	public $clt;

	/** @var int Rang */
	public $rank;

	/** @var float Point */
	public $points;

}

class Pair{
	/** @var int identifiant */
	public $id;

	/** @var Player Joueur 1 */
	public $player1;

	/** @var Player Joueur 2 */
	public $player2;

    /** @var int Position de la paire haute=130; basse=131*/
    public $pos;
}

class Match{
	/** @var int identifiant de la base */
	public $baseid;

    /** @var int identifiant du tournoi */
	public $eventid;

	/** @var int identifiant */
	public $id;

	/** @var string nom du tournoi */
	public $eventname;

    /** @var string Serie (A, B, Benjamin..) ou rencontre (Equipe A-Equipe B) */
	public $draw;

    /** @var string Tour (Poule A; 1/2 finale) */
	public $round;

    /** @var string Tour  */
	public $step;

	/** @var string Label (SH 1; SH BEN) */
	public $label;

	/** @var string Nom de le salle */
	public $sporthall;

	/** @var int Numero du match*/
	public $number;

	/** @var int Numero du terrain*/
	public $court;

	/** @var string Heure prevue yyyy-mm-jj hh:mm:ss */
	public $schedule;

	/** @var boolean indicateur de double */
	public $isdouble;

	/** @var boolean indicateur de live scoring */
	public $islivescoring;

    /** @var Paire Paire 1 */
	public $pair1;

    /** @var Paire Paire 2 */
	public $pair2;

}
class Event{
   	/** @var int identifiant de la base */
	public $baseid;

	/** @var int identifiant */
	public $id;

	/** @var string nom du tournoi */
	public $name;

	/** @var string nom du tournoi */
	public $place;
}
class Matchdef{
	/** @var string nom du tournoi */
	public $name;

	/** @var string nom du tournoi */
	public $number;

	/** @var string nom du tournoi */
	public $step;
}

ic::setProject('Conf');
class Scorbad {
    /**
     * getMatch Method
     *
     * @return string The object match
     */
    //function getMatch($aEventId, $aNumMatch){
    function getMatch($aEventId, $aNumMatch, $aCode=0){
        ic::log("$aEventId, $aNumMatch, $aCode", 'history', false);
        if ($aEventId < 0){
            return self::_badnetTeamGetMatch($aNumMatch);
        }

        $oMatch = new Match();
        $q = new icQuery('events');
        $q->addTable('draws', 'evnt_id=draw_eventid');
        $q->addTable('rounds', 'draw_id=rund_drawid');
        $q->addTable('ties', 'rund_id=tie_roundid');
        $q->addTable('matchs', 'tie_id=mtch_tieid');
        $q->addWhere('draw_eventid =' . $aEventId);
        $q->addWhere('mtch_num =' . $aNumMatch);

        $q->addField('evnt_type', 'eventtype');
        $q->addField('evnt_fromid', 'fromid');
        $q->addField('evnt_fromdatabase', 'fromdatabase');
        $q->addField('evnt_name', 'eventname');
        $q->addField('draw_name', 'draw');
        $q->addField('draw_stamp', 'drawstamp');
        $q->addField('rund_name', 'roundname');
        $q->addField('rund_id', 'roundid');
        $q->addField('rund_type', 'roundtype');

        $q->addField('mtch_id', 'id');
        $q->addField('tie_place', 'sporthall');
        $q->addField('mtch_num', 'number');
        $q->addField('mtch_court', 'court');
        $q->addField('mtch_discipline', 'discipline');
        $q->addField('mtch_scorbad', 'code');
        $q->addField('mtch_order', 'theorder');
        $q->addField('tie_schedule', 'schedule');
        $q->addField('tie_posround', 'posround');
        //$q->addField('tie_round', 'round');
        $q->addField('tie_step', 'step');
        $match = $q->getRow();
       if (empty($match) ){
            return -1;
        }
        else if ( $aCode == $match['code'] ){
            $oMatch->number = $match['number'];
        }
        else {
            $oMatch->number = -$match['number'];
        }

        if ($match['roundtype'] == CROUND_TYPE_MAINDRAW
        || $match['roundtype'] == CROUND_TYPE_PLATEAU
        || $match['roundtype'] == CROUND_TYPE_QUALIF){
            $labels = array(CTIE_STAGE_FINAL => 'Finale',
                CTIE_STAGE_SEMI => '1/2',
                CTIE_STAGE_QUATER => '1/4',
                CTIE_STAGE_HEIGHT => '1/8',
                CTIE_STAGE_16 => '1/16',
                CTIE_STAGE_32 => '1/32',
                CTIE_STAGE_64 => '1/64',
                CTIE_STAGE_128 => '1/128');
            //if ( !empty($match['round']) )
            //    $oMatch->round = $labels[$match['round']];
            //else
            //    $oMatch->round = $labels[$match['step']];

            // Nuero du match das le tour ex : 1/4 numero 1
            if(!$match['posround']){
                $num = 1;
                $oMatch->round = 'Finale';
            }
            else if($match['posround']<3){
                $num = $match['posround'];
                $oMatch->round = '1/2';
            }
            else if($match['posround']<7){
                $num = $match['posround']-2;
                $oMatch->round = '1/4';
            }
            else if($match['posround']<15){
                $num = $match['posround']-6;
                $oMatch->round = '1/8';
            }
            else if($match['posround']<31){
                $num = $match['posround']-14;
                $oMatch->round = '1/16';
            }
            else if($match['posround']<63){
                $num = $match['posround']-30;
                $oMatch->round = '1/32';
            }
            else if($match['posround']<127){
                $num = $match['posround']-62;
                $oMatch->round = '1/64';
            }
            else{
                $num = $match['numtie']-126;
                $oMatch->round = '1/128';
            }
            $oMatch->step = $num;
        }
        else{
            $oMatch->round = $match['roundname'];
            $oMatch->step = $match['posround']+1;
        }

        switch($match['discipline']){
            case CMATCH_DISCI_MS;
                $oMatch->label = 'SH';
                $oMatch->isdouble = 0;
                break;
            case CMATCH_DISCI_WS;
                $oMatch->label = 'SD';
                $oMatch->isdouble = 0;
                break;
            case CMATCH_DISCI_AS;
                $oMatch->label = 'S';
                $oMatch->isdouble = 0;
                break;
            case CMATCH_DISCI_MD;
                $oMatch->label = 'DH';
                $oMatch->isdouble = 1;
                break;
            case CMATCH_DISCI_WD;
                $oMatch->label = 'DD';
                $oMatch->isdouble = 1;
                break;
            case CMATCH_DISCI_AD;
                $oMatch->label = 'D';
                $oMatch->isdouble = 1;
                break;
            case CMATCH_DISCI_MX;
                $oMatch->label = 'Mx';
                $oMatch->isdouble = 1;
                break;
            default :
                $oMatch->isdouble = 0;
                break;
        }

        // Interclub ou par équipe
        if ( $match['eventtype'] == CEVENT_TYPE_IC ){
            $q->setTables('teams');
            $q->addTable('t2r', 't2r_teamid=team_id');
            $q->addWhere('rund_id=' . $match['roundid']);
            $q->addField('team_stamp');
            $q->addField('team_number');
            $teams = $q->getCol();
            $oMatch->draw = implode(" - " , $teams);
            $temps = explode(';', $match['order']);
            foreach($temps as $temp){
                list($disci, $nb) = explode(':', $temp);
                if ( $disci== $match['discipline'] && $nb>1 ){
                    $oMatch->label .= ' ' . $match['theorder'];
                    break;
                }
            }
        }
        // individuel
        elseif ( $match['eventtype'] == CEVENT_TYPE_INDIVIDUAL ){
            $oMatch->draw = $match['draw'];
            $oMatch->label = $match['drawstamp'];

        }
        // Autre (cirquit, calendrier)
        else{
            $oMatch->draw = '';
        }

        // Joueurs du match
        $q->setTables('teams');
        $q->addTable('registration', 'regi_teamid=team_id');
        $q->addTable('members', 'regi_memberid=mber_id');
        $q->addTable('i2p', 'regi_id=i2p_regiid');
        $q->addTable('p2m', 'i2p_pairid=p2m_pairid');
        $q->addTable('rankdef', 'i2p_rankdefid=rkdf_id');
        $q->addWhere('p2m_matchid=' . $match['id']);
        $q->addField('regi_id', 'id');
        $q->addField('team_name', 'teamname');
        $q->addField('mber_firstname', 'firstname');
        $q->addField('mber_secondname', 'famname');
        $q->addField('mber_licence', 'license');
        $q->addField('mber_sexe', 'gender');
        //$q->addField('mber_country', 'noc');
        $q->addField('rkdf_label', 'clt');
        $q->addField('i2p_cppp', 'points');
        $q->addField('i2p_classe', 'rank');
        $q->addField('i2p_pairid', 'pairid');
        $q->addField('p2m_posmatch', 'posmatch');
        $q->setOrder('i2p_pairid, mber_sexe, mber_secondname');
        $players = $q->getRows();
        $pairId = 'none';
        $numPair = 0;
        $oPair1 = new Pair();
        $oPair2 = new Pair();
        foreach($players as $player){
            if ( $pairId != $player['pairid'] ){
                $pairId = $player['pairid'];
                $numPlayer = 1;
                $numPair++;
            }

            $oPlayer = new Player();
            $oPlayer->clt = $player['clt'];
            $oPlayer->id = $player['id'];
            $oPlayer->team = $player['teamname'];
            $oPlayer->familyname = $player['famname'];
            $oPlayer->firstname = $player['firstname'];
            $oPlayer->license = $player['license'];
            $oPlayer->gender = $player['gender'];
            $oPlayer->points = $player['points'];
            $oPlayer->rank = $player['rank'];
            $oPlayer->noc = ''; //$player['noc'];
            if ( $numPair == 1){
                $oPair1->id = $pairId;
                $oPair1->pos = $player['posmatch'];
                if ($numPlayer == 1)
                    $oPair1->player1 = $oPlayer;
                else
                    $oPair1->player2 = $oPlayer;
            }
            else{
                $oPair2->id = $pairId;
                $oPair2->pos = $player['posmatch'];
                if ($numPlayer == 1)
                    $oPair2->player1 = $oPlayer;
                else
                    $oPair2->player2 = $oPlayer;
            }
            $numPlayer++;
        }
        $oMatch->pair1 = $oPair1;
        $oMatch->pair2 = $oPair2;

        $oMatch->baseid = $match['fromdatabase'];
        $oMatch->eventid = $match['fromid'];
        $oMatch->eventname = $match['eventname'];
        $oMatch->id = $match['id'];
        $oMatch->sporthall = $match['sporthall'];
        $oMatch->court = $match['court'];
        $oMatch->schedule = $match['schedule'];
        $oMatch->islivescoring = 1;
        ic::log($oMatch);
        return $oMatch;
    }

    function _badnetTeamGetMatch($aMatchId){
        $oMatch = new Match();

        $q = new icQuery('tie', '_team');
        $q->addTable('match', 'mtch_tieid=tie_id');
        $q->addField('mtch_id', 'number');
        $q->addField('mtch_disci', 'disci');
        $q->addField('mtch_rank', 'rank');
        $q->addField('mtch_playh1id', 'playh1id');
        $q->addField('mtch_playh2id', 'playh2id');
        $q->addField('mtch_playv1id', 'playv1id');
        $q->addField('mtch_playv2id', 'playv2id');
        $q->addField('tie_teamhid', 'teamhid');
        $q->addField('tie_teamvid', 'teamvid');
        $q->addField('tie_sporthall', 'sporthall');
        $q->addField('tie_schedule', 'schedule');
        $q->addField('mtch_court', 'court');
        $q->addField('mtch_rank', 'rank');
        $q->addField('mtch_id', 'id');
        $q->addField('tie_division', 'division');
        $q->addField('tie_group', 'round');
        $q->addWhere('mtch_id = '. $aMatchId);
        $match = $q->getRow();

        //$oMatch->round = $match['roundname'];
        //$oMatch->step = $match['posround']+1;

        switch($match['disci']){
            case CMATCH_DISCI_MS;
                $oMatch->label = 'SH';
                $oMatch->isdouble = 0;
                $disci = 's';
                break;
            case CMATCH_DISCI_WS;
                $oMatch->label = 'SD';
                $oMatch->isdouble = 0;
                $disci = 's';
                break;
            case CMATCH_DISCI_AS;
                $oMatch->label = 'S';
                $oMatch->isdouble = 0;
                $disci = 's';
                break;
            case CMATCH_DISCI_MD;
                $oMatch->label = 'DH';
                $oMatch->isdouble = 1;
                $disci = 'd';
                break;
            case CMATCH_DISCI_WD;
                $oMatch->label = 'DD';
                $oMatch->isdouble = 1;
                $disci = 'd';
                break;
            case CMATCH_DISCI_AD;
                $oMatch->label = 'D';
                $oMatch->isdouble = 1;
                $disci = 'd';
                break;
            case CMATCH_DISCI_MX;
                $oMatch->label = 'Mx';
                $oMatch->isdouble = 1;
                $disci = 'm';
                break;
            default :
                $oMatch->label = '';
                $oMatch->isdouble = 0;
                $disci = 's';
                break;
        }
        $oMatch->label .= ' ' . $match['rank'];
        $q->setTables('team');
        $q->addField('team_stamp');
        $q->addWhere('team_id=' . $match['teamhid']);
        $oMatch->draw = $q->getFirst() . ' - ';
        $q->setWhere('team_id=' . $match['teamvid']);
        $oMatch->draw .= $q->getFirst();
        $oMatch->round = $oMatch->draw;

        // Joueurs du match
        $q->setTables('player');
        $q->addTable('team', 'play_teamid=team_id');
        $q->addWhere('play_id=' . $match['playh1id']);
        $q->addField('play_id', 'id');
        $q->addField('team_name', 'teamname');
        $q->addField('play_firstname', 'firstname');
        $q->addField('play_famname', 'famname');
        $q->addField('play_license', 'license');
        $q->addField('play_gender', 'gender');
        //$q->addField('', 'noc');
        $q->addField('play_levels', 'clts');
        $q->addField('play_leveld', 'cltd');
        $q->addField('play_levelm', 'cltm');
        $q->addField('play_points', 'points');
        $q->addField('play_pointd', 'pointd');
        $q->addField('play_pointm', 'pointm');
        $q->addField('play_ranks', 'ranks');
        $q->addField('play_rankd', 'rankd');
        $q->addField('play_rankm', 'rankm');
        $player = $q->getRow();

        $oPair1 = new Pair();
        $oPair1->id = 1;
        $oPair1->pos = CMATCH_PAIR_TOP;
        if ( $match['playh1id'] > 0){
            $oPlayer = new Player();
            $oPlayer->id = $player['id'];
            $oPlayer->team = $player['teamname'];
            $oPlayer->familyname = $player['famname'];
            $oPlayer->firstname = $player['firstname'];
            $oPlayer->license = $player['license'];
            $oPlayer->gender = $player['gender'];
            $oPlayer->noc = '';
            $oPlayer->clt = $player['clt' . $disci];
            $oPlayer->points = $player['point' . $disci];
            $oPlayer->rank = $player['rank' . $disci];
            $oPair1->player1 = $oPlayer;
        }
        if ( $match['playh2id'] > 0){
            $q->setWhere('play_teamid=team_id');
            $q->addWhere('play_id=' . $match['playh2id']);
            $player = $q->getRow();

            $oPlayer = new Player();
            $oPlayer->id = $player['id'];
            $oPlayer->team = $player['teamname'];
            $oPlayer->familyname = $player['famname'];
            $oPlayer->firstname = $player['firstname'];
            $oPlayer->license = $player['license'];
            $oPlayer->gender = $player['gender'];
            $oPlayer->noc = '';
            $oPlayer->clt = $player['clt' . $disci];
            $oPlayer->points = $player['point' . $disci];
            $oPlayer->rank = $player['rank' . $disci];
            $oPair1->player2 = $oPlayer;
        }

        $oPair2 = new Pair();
        $oPair2->id = 1;
        $oPair2->pos = CMATCH_PAIR_BOTTOM;
        if ( $match['playv1id'] > 0){
            $q->setWhere('play_teamid=team_id');
            $q->addWhere('play_id=' . $match['playv1id']);
            $player = $q->getRow();

            $oPlayer = new Player();
            $oPlayer->id = $player['id'];
            $oPlayer->team = $player['teamname'];
            $oPlayer->familyname = $player['famname'];
            $oPlayer->firstname = $player['firstname'];
            $oPlayer->license = $player['license'];
            $oPlayer->gender = $player['gender'];
            $oPlayer->noc = '';
            $oPlayer->clt = $player['clt' . $disci];
            $oPlayer->points = $player['point' . $disci];
            $oPlayer->rank = $player['rank' . $disci];
            $oPair2->player1 = $oPlayer;
        }
        if ( $match['playv2id'] > 0){
            $q->setWhere('play_teamid=team_id');
            $q->addWhere('play_id=' . $match['playv2id']);
            $player = $q->getRow();

            $oPlayer = new Player();
            $oPlayer->id = $player['id'];
            $oPlayer->team = $player['teamname'];
            $oPlayer->familyname = $player['famname'];
            $oPlayer->firstname = $player['firstname'];
            $oPlayer->license = $player['license'];
            $oPlayer->gender = $player['gender'];
            $oPlayer->noc = '';
            $oPlayer->clt = $player['clt' . $disci];
            $oPlayer->points = $player['point' . $disci];
            $oPlayer->rank = $player['rank' . $disci];
            $oPair2->player2 = $oPlayer;
        }
        $oMatch->pair1 = $oPair1;
        $oMatch->pair2 = $oPair2;

        $q->setTables('event');
        $q->addField('evnt_name', 'eventname');
        //$q->addField('evnt_type', CEVENT_TYPE_IC);
        $event = $q->getRow();

        $oMatch->baseid = 0;//'_team';
        $oMatch->eventid = -1;
        $oMatch->eventname = $event['eventname'];
        $oMatch->id = $match['id'];
        $oMatch->sporthall = $match['sporthall'];
        $oMatch->number = $match['id'];
        $oMatch->court = $match['court'];
        $oMatch->schedule = $match['schedule'];
        $oMatch->islivescoring = 1;
        return $oMatch;
    }

    function getEvents(){
        $q = new icQuery('events');
        $q->addTable('draws', 'draw_eventid=evnt_id');
        $q->addTable('rounds', 'rund_drawid=draw_id');
        $q->addTable('ties', 'tie_roundid=rund_id');

        $q->addField('DISTINCT tie_place', 'place');
        $q->addField('evnt_id', 'id');
        $q->addField('evnt_name', 'name');

        $q->addWhere('evnt_season=' . self::currentId());
        $q->addWhere("tie_place!=''");
        $rows = $q->getRows();

        $oEvents = array();
        foreach($rows as $row){
            $oEvent = new Event();
            $oEvent->baseid = 0;
            $oEvent->id = $row['id'];
            $oEvent->name = $row['name'];
            $oEvent->place = $row['place'];
            $oEvents[] = $oEvent;
        }

        $q = new icQuery('event', '_team');
        $q->addField('evnt_place', 'place');
        $q->addField('evnt_numid', 'numid');
        $q->addField('evnt_name', 'name');
        $rows = $q->getRows();
        foreach($rows as $row){
            $oEvent = new Event();
            $oEvent->baseid = -1;
            $oEvent->id = $row['numid'];
            $oEvent->name = $row['name'];
            $oEvent->place = $row['place'];
            $oEvents[] = $oEvent;
        }
        return $oEvents;
    }

    function getMatchs($aEventId, $aPlace='', $aNb = 10){
        if ($aEventId < 0){
            return self::_badnetTeamGetMatchs($aNb);
        }
        $q = new icQuery('draws');
        $q->addTable('rounds', 'rund_drawid=draw_id');
        $q->addTable('ties', 'tie_roundid=rund_id');
        $q->addTable('matchs', 'mtch_tieid=tie_id');
        $q->addTable('events', 'draw_eventid=evnt_id');

        $q->addField('evnt_type', 'eventtype');
        $q->addField('draw_stamp', 'drawstamp');
        $q->addField('rund_name', 'roundname');
        $q->addField('rund_id', 'roundid');
        $q->addField('rund_type', 'roundtype');

        $q->addField('mtch_id', 'id');
        $q->addField('mtch_num', 'number');
        $q->addField('mtch_discipline', 'discipline');
        $q->addField('mtch_order', 'theorder');
        $q->addField('tie_schedule', 'schedule');
        $q->addField('tie_posround', 'posround');
        $q->addField('tie_step', 'step');

        $q->addWhere('tie_isbye=0');
        $q->addWhere('mtch_status <= '. CMATCH_STATUS_LIVE);
        $q->addWhere('mtch_status > '. CMATCH_STATUS_INCOMPLET);
        $q->addWhere('draw_eventid=' . $aEventId);
        if (!empty($aPlace) ){
            $q->addWhere("tie_place='" . addslashes($aPlace) . "'");
        }
        $q->setOrder('mtch_num');
        $q->setLimit(1, $aNb);
        $matchs = $q->getRows();

        $oMatchs = array();
        $disciLabels = array(
            CMATCH_DISCI_MS => 'SH',
            CMATCH_DISCI_WS => 'SD',
            CMATCH_DISCI_AS => 'ST',
            CMATCH_DISCI_MD => 'DH',
            CMATCH_DISCI_WD => 'DD',
            CMATCH_DISCI_AD => 'DT',
            CMATCH_DISCI_MX => 'Mx'
        );
        $stepLabels = array(CTIE_STAGE_FINAL => 'Finale',
                        CTIE_STAGE_SEMI => '1/2',
                        CTIE_STAGE_QUATER => '1/4',
                        CTIE_STAGE_HEIGHT => '1/8',
                        CTIE_STAGE_16 => '1/16',
                        CTIE_STAGE_32 => '1/32',
                        CTIE_STAGE_64 => '1/64',
                        CTIE_STAGE_128 => '1/128',
                        0 => '',
                        1 => '');

        foreach($matchs as &$match){
            $oMatch = new Matchdef();
            $oMatch->number = $match['number'];
            // Interclub ou par équipe
            if ( $match['eventtype'] == CEVENT_TYPE_IC ){

                $oMatch->step = $disciLabels[$match['discipline']];
                $q->setTables('teams');
                $q->addTable('t2r', 't2r_teamid=team_id');
                $q->addWhere('rund_id=' . $match['roundid']);
                $q->addField('team_stamp');
                $teams = $q->getCol();
                $oMatch->name = implode(" - " , $teams);
                $temps = explode(';', $match['order']);
                foreach($temps as $temp){
                    list($disci, $nb) = explode(':', $temp);
                    if ( $disci== $match['discipline'] && $nb>1 ){
                        $oMatch->step .= ' ' . $match['theorder'];
                        break;
                    }
                }
            }
            // individuel
            elseif ( $match['eventtype'] == CEVENT_TYPE_INDIVIDUAL ){
                if ($match['roundtype'] == CROUND_TYPE_MAINDRAW
                || $match['roundtype'] == CROUND_TYPE_PLATEAU
                || $match['roundtype'] == CROUND_TYPE_QUALIF){
                    if ( !empty($match['round']) )
                        $step = $stepLabels[$match['round']];
                    else
                        $step = $stepLabels[$match['step']];

                    // Nuero du match das le tour ex : 1/4 numero 1
                    if(!$match['posround']) $num = 1;
                    else if($match['posround']<3) $num = $match['posround'];
                    else if($match['posround']<7) $num = $match['posround']-2;
                    else if($match['posround']<15) $num = $match['posround']-6;
                    else if($match['posround']<31) $num = $match['posround']-14;
                    else if($match['posround']<63) $num = $match['posround']-30;
                    else if($match['posround']<127) $num = $match['posround']-62;
                    else $num = $match['numtie']-126;
                    $oMatch->step = $step . ' ' . $num;
                }
                else{
                    $oMatch->step = $match['roundname'];
                }
                $oMatch->name = $match['drawstamp'];
                $oMatch->schedule = $match['schedule'];
            }
            $oMatchs[] = $oMatch;
        }
        return $oMatchs;
    }

    function _badnetTeamGetMatchs($aNb = 10){
        $q = new icQuery('event', '_team');
        $q->addField('evnt_name', 'eventname');
        $eventname = $q->getRow();

        $q->setTables('tie');
        $q->addTable('match', 'mtch_tieid=tie_id');
        $q->addField('mtch_id', 'id');
        $q->addField('mtch_order', 'matchorder');
        $q->addField('tie_schedule', 'schedule');
        $q->addField('mtch_disci', 'discipline');
        $q->addField('tie_teamhid', 'teamhid');
        $q->addField('tie_teamvid', 'teamvid');

        $q->addWhere('mtch_status < '. CMATCH_STATUS_LIVE);
        $q->addWhere('mtch_status > '. CMATCH_STATUS_INCOMPLET);
        $q->setOrder('mtch_id');
        $q->setLimit(1, $aNb);
        $matchs = $q->getRows();
        $disciLabels = array(
            CMATCH_DISCI_MS => 'SH',
            CMATCH_DISCI_WS => 'SD',
            CMATCH_DISCI_AS => 'ST',
            CMATCH_DISCI_MD => 'DH',
            CMATCH_DISCI_WD => 'DD',
            CMATCH_DISCI_AD => 'DT',
            CMATCH_DISCI_MX => 'Mx'
        );

        $oMatchs = array();
        foreach($matchs as &$match){
            $oMatch = new Matchdef();
            $oMatch->number = $match['id'];
            $oMatch->schedule = $match['schedule'];
            $label = $disciLabels[$match['discipline']];
            $oMatch->step = $label. ' ' . $match['matchorder'];
            $q->setTables('team');
            $q->addField('team_stamp');
            $q->addWhere('team_id=' . $match['teamhid']);
            $name = $q->getFirst() . ' - ';
            $q->setWhere('team_id=' . $match['teamvid']);
            $name .= $q->getFirst();
            $oMatch->name = $name;
            $oMatchs[] = $oMatch;
        }
        return $oMatchs;
    }

    function result($aEventId, $aNumMatch, $aBegin, $aEnd, $aScore, $aPosWinner=0, $aDatabase=0, $aAuto=false){

        ic::log("$aEventId, $aNumMatch, $aBegin, $aEnd, $aScore, $aPosWinner, $aDatabase, $aAuto", 'history', false);
        if ($aNumMatch <= 0) {
            return false;
        }
        if ($aEventId < 0){
            $res = self::_badnetTeamResult($aNumMatch, $aBegin, $aEnd, $aScore, $aPosWinner);
            return $res;
        }

        // Id du match
        $q = new icQuery('draws', $aDatabase);
        $q->addTable('rounds', 'rund_drawid=draw_id');
        $q->addTable('ties', 'tie_roundid=rund_id');
        $q->addTable('matchs', 'mtch_tieid=tie_id');

        $q->addField('mtch_id', 'matchid');
        $q->addField('mtch_court', 'court');
        $q->addField('rund_type', 'roundtype');
        $q->addField('tie_posround', 'posround');
        $q->addField('tie_looserdrawid', 'looserdrawid');
        $q->addField('tie_place', 'place');
        $q->addField('rund_id', 'roundid');

        $q->addWhere('mtch_num = '. $aNumMatch);
        $q->addWhere('draw_eventid=' . $aEventId);
        $match = $q->getRow();
        if ( empty($match) ) return;

        // Mise à jour du match
        $q->setTables('matchs');
		$q->addValue('mtch_score', $aScore);
		$q->addValue('mtch_begin', $aBegin);
		$q->addValue('mtch_end', $aEnd);
        if ( $aPosWinner != CMATCH_PAIR_TOP && $aPosWinner != CMATCH_PAIR_BOTTOM){
            $q->updateRow('mtch_id=' . $match['matchid']);
            return;
        }
        $q->addValue('mtch_status', CMATCH_STATUS_CLOSED);
        $q->updateRow('mtch_id=' . $match['matchid']);

        // Mise à jour des paires
        $ext = strtolower(substr(trim($aScore), -2));
        if ( $ext == 'ab' ){
            $winResult = CMATCH_RESULT_WINAB;
            $looseResult = CMATCH_RESULT_LOOSEAB;
        }
        if ( $ext == 'wo' ){
            $winResult = CMATCH_RESULT_WINWO;
            $looseResult = CMATCH_RESULT_LOOSEWO;
        }
        else{
            $winResult = CMATCH_RESULT_WIN;
            $looseResult = CMATCH_RESULT_LOOSE;
        }
        $posLooser = $aPosWinner == CMATCH_PAIR_TOP ? CMATCH_PAIR_BOTTOM : CMATCH_PAIR_TOP;
		$q->setTables('p2m');
		$q->addField('p2m_pairid');
        $q->addValue('p2m_result',   $winResult);
        $q->setWhere('p2m_matchid=' . $match['matchid']);
        $q->addWhere('p2m_posmatch=' . $aPosWinner);
        $q->replaceRow();
        $winPairId = $q->getFirst();

        $q->setValue('p2m_result',   $looseResult);
        $q->setWhere('p2m_matchid='.  $match['matchid']);
        $q->addWhere('p2m_posmatch=' . $posLooser);
        $q->replaceRow();
        $loosePairId = $q->getFirst();

        // Mise à jour du tableau
        if ( $match['roundtype'] != CROUND_TYPE_GROUP && $match['roundtype'] != CROUND_TYPE_AR){

            // Donnée du match suivant
            $posRound = $match['posround'];
            // Finale, rien a faire
            if (!$posRound) return;
            $tiePosRound = intval(($posRound-1)/2);
            $pairPos = ($posRound%2) ? CMATCH_PAIR_TOP : CMATCH_PAIR_BOTTOM;

            // Match suivant
            $q->setTables('matchs');
            $q->addTable('ties', 'mtch_tieid=tie_id');
            $q->addWhere('tie_roundid=' . $match['roundid']);
            $q->addWhere('tie_posround=' . $tiePosRound);
            $q->setFields('mtch_id');
            $nextMatchId = $q->getFirst();

            // Mise a jour de la paire
            if ( !empty($nextMatchId) ){
                $q->setTables('p2m');
                $q->setWhere('p2m_posmatch=' . $pairPos);
                $q->addWhere('p2m_matchid=' . $nextMatchId);
                $q->setValue('p2m_pairid', $winPairId);
                $q->addValue('p2m_posmatch', $pairPos);
                $q->addValue('p2m_matchid', $nextMatchId);
                $q->replaceRow();

                // Nombe de paire du match
                $q->setTables('p2m');
                $q->addWhere('p2m_matchid=' . $nextMatchId);
                $q->setFields('count(*)');
                $nb = $q->getFirst();

                // Mise a jour de l'état du match
                $q->setTables('matchs');
                $q->addWhere('mtch_id=' . $nextMatchId);
                $q->addWhere('mtch_status <' . CMATCH_STATUS_LIVE);
                if ($nb < 2)  $q->addValue('mtch_status', CMATCH_STATUS_INCOMPLET);
                else $q->addValue('mtch_status', CMATCH_STATUS_READY);
                $q->replaceRow();
            }
            // Si c'est un tableau de qualif, le vainqueur doit etre bascule dans le tableau principal
            else if ( $this->getVal('type') == CROUND_TYPE_QUALIF ) {
                $q->setTables('pairs');
                $q->setValue('pair_status', CPAIR_STATUS_MAINDRAW);
                $q->updateRow('pair_id=' . $winPairId);
                $q->setValue('pair_status', CPAIR_STATUS_QUALIF);
                $q->updateRow('pair_id=' . $loosePairId);
            }

            // Mise a jour du plateau perdant
            $roundId = $match['looserdrawid'];
            if ( $roundId > 0){
                // Taille du tableau
                $q->setTables('rounds');
                $q->addWhere('rund_id=' . $roundId);
                $q->setFields('rund_size');
                $size = $q->getFirst();
                $limit = max(0, $size-2);
                $tiePosRound = $posRound;
                $step = 0;
                do{
                    $t2rPosRound = $tiePosRound;
                    $tiePosRound = ceil($tiePosRound/2)-1;
                    $step++;
                }
                while ($tiePosRound > $limit);

                // Est ce un bye
                $q->setTables('rounds');
                $q->addTable('ties', 'tie_roundid=rund_id');
                $q->addWhere('rund_id=' . $roundId);
                $q->addWhere('tie_posround=' . $tiePosRound);
                $q->setFields('tie_isbye');
                $isBye = $q->getFirst();

                $posRound = $t2rPosRound - 62;
                if ($posRound <= 0) $posRound = $t2rPosRound - 30;
                if ($posRound <= 0) $posRound = $t2rPosRound - 14;
                if ($posRound <= 0) $posRound = $t2rPosRound - 6;
                if ($posRound <= 0) $posRound = $t2rPosRound - 2;
                if ($posRound <= 0) $posRound = $t2rPosRound;

                if($isBye && $step ==1){
                    if( ($posRound>$size/2) && $tiePosRound) $posRound++;
                    else $posRound--;
                }
                $pairPos = ($posRound%2) ? CMATCH_PAIR_TOP : CMATCH_PAIR_BOTTOM;;

                // Positionner la paire dans le tableau
                $pairId = $loosePairId;
                $q->setTables('t2r');
                $q->addValue('t2r_roundid', $roundId);
                $q->addValue('t2r_pairid', $pairId);
                $q->addValue('t2r_posround', $posRound);
                $q->setWhere('t2r_roundid=' . $roundId);
                $q->addWhere('t2r_posround=' . $posRound);
                $q->replaceRow();

                // Match du joueur
                $q->setTables('matchs');
                $q->addTable('ties', 'mtch_tieid=tie_id');
                $q->addWhere('tie_roundid=' . $roundId);
                $q->addWhere('tie_posround=' . $tiePosRound);
                $q->setFields('mtch_id');
                $nextMatchId = $q->getFirst();

                // Mise a jour de la paire
                $q->setTables('p2m');
                $q->setWhere('p2m_posmatch=' . $pairPos);
                $q->addWhere('p2m_matchid=' . $nextMatchId);
                $q->setValue('p2m_pairid', $pairId);
                $q->addValue('p2m_posmatch', $pairPos);
                $q->addValue('p2m_matchid', $nextMatchId);
                if ( $isBye ) $q->addValue('p2m_result', CMATCH_RESULT_WIN);
                $q->replaceRow();

                // Nombre de paires du match
                $q->setTables('p2m');
                $q->addWhere('p2m_matchid=' . $nextMatchId);
                $q->setFields('count(*)');
                $nb = $q->getFirst();

                // Mise a jour de l'état du match
                $q->setTables('matchs');
                $q->addWhere('mtch_id=' . $nextMatchId);
                $q->addWhere('mtch_status <' . CMATCH_STATUS_LIVE);
                if ($nb < 2)  $q->addValue('mtch_status', CMATCH_STATUS_INCOMPLET);
                else $q->addValue('mtch_status', CMATCH_STATUS_READY);
                $q->replaceRow();

                if ($isBye == 1 && $tiePosRound>0){
                    $pairPos = ($tiePosRound%2) ? CMATCH_PAIR_TOP : CMATCH_PAIR_BOTTOM;;
                    $tiePosRound = intval(($tiePosRound-1)/2);

                    // Match du joueur
                    $q->setTables('matchs');
                    $q->addTable('ties', 'mtch_tieid=tie_id');
                    $q->addWhere('tie_roundid=' . $roundId);
                    $q->addWhere('tie_posround=' . $tiePosRound);
                    $q->setFields('mtch_id');
                    $nextMatchId = $q->getFirst();

                    // Mise a jour de la paire
                    $q->setTables('p2m');
                    $q->setWhere('p2m_posmatch=' . $pairPos);
                    $q->addWhere('p2m_matchid=' . $nextMatchId);
                    $q->setValue('p2m_pairid', $pairId);
                    $q->addValue('p2m_posmatch', $pairPos);
                    $q->addValue('p2m_matchid', $nextMatchId);
                    $q->replaceRow();

                    // Nombre de paires du match
                    $q->setTables('p2m');
                    $q->addWhere('p2m_matchid=' . $nextMatchId);
                    $q->setFields('count(*)');
                    $nb = $q->getFirst();

                    // Mise a jour de l'état du match
                    $q->setTables('matchs');
                    $q->addWhere('mtch_id=' . $nextMatchId);
                    $q->addWhere('mtch_status <' . CMATCH_STATUS_LIVE);
                    if ($nb < 2)  $q->addValue('mtch_status', CMATCH_STATUS_INCOMPLET);
                    else $q->addValue('mtch_status', CMATCH_STATUS_READY);
                    $q->replaceRow();
                }
            }

        }

        // Mise a jour du temps de repos
        $q->setTables('matchs');
        $q->addTable('p2m', 'p2m_matchid=mtch_id');
        $q->addTable('i2p', 'i2p_pairid=p2m_pairid');
		$q->addField('i2p_regiId');
		$q->addWhere('mtch_id = ' . $match['matchid']);
		$regiIds = $q->getCol();

        $q->setTables('registration');
		$q->setValue('regi_rest', $aEnd);
		$q->addWhere("regi_id in (". implode(',', $regiIds) .")");
        $where = "(regi_rest < '". $aEnd ."' OR regi_rest IS NULL OR regi_rest='0000-00-00 00:00:00')";
        $q->addWhere($where);
		$q->updateRow();

        // Renvoi du match suivant si besoin
        $ret = false;
        if ( $aAuto ){
           $oMatchs = self::getMatchs($aEventId, $match['place'], 1, $aDatabase);
           if ( count($oMatchs) ){
               $oMatch = reset($oMatchs);
               $ret = self::getMatch($aEventId, $oMatch->number, $aDatabase);
               $q->setTables('matchs');
               $q->setValue('mtch_court', $match['court']);
               $q->setValue('mtch_status', CMATCH_STATUS_LIVE);
               $q->updateRow('mtch_id=' . $ret->id);
           }
        }

        self::_updateMatchStatus($aEventId, $match['place']);
        return $ret;
    }

    function _updateMatchStatus($aEventId, $aPlace){
        // ---- Mise a jour du status des matchs ----
		// Initialisation des match en cours ou en repos
		$q = new icQuery('draws');
        $q->addTable('rounds', 'rund_drawid=draw_id');
        $q->addTable('ties', 'tie_roundid=rund_id');
        $q->addTable('matchs', 'mtch_tieid=tie_id');
        $q->setFields('mtch_id');
		$where = "(mtch_status =".CMATCH_STATUS_BUSY.
                " OR mtch_status =".CMATCH_STATUS_REST. " ) ";
        $q->addWhere($where);
        $q->addWhere('draw_eventid =' . $aEventId);
        $matchIds = $q->getCol();
        if ( !empty($matchIds) ){
            $q->setTables('matchs');
            $q->setValue('mtch_status', CMATCH_STATUS_READY);
            $q->addWhere('mtch_id in (' . implode(',', $matchIds) . ')');
            $q->updateRow();
        }

        // Initialiser les joueurs : terrains a zero
        $q->setTables('registration');
        $q->setWhere('regi_eventid=' . $aEventId);
        $q->setValue('regi_court', 0);
        $q->updateRow();

        // Match en cours
		$q->setTables('draws');
        $q->addTable('rounds', 'rund_drawid=draw_id');
        $q->addTable('ties', 'tie_roundid=rund_id');
        $q->addTable('matchs', 'mtch_tieid=tie_id');
        $q->setFields('mtch_id');
        $q->addField('mtch_court');
        $q->addField('mtch_umpireid');
        $q->addField('mtch_serviceid');
        $q->addWhere('mtch_status =' . CMATCH_STATUS_LIVE);
        $q->addWhere('draw_eventid =' . $aEventId);
        $matchs = $q->getRows();

        // Aucun match :rien a faire
        if ( empty($matchs) ) {
            return false;
        }
        // Mise a jour des acteurs des matchs
        $allregiIds = array();
        foreach($matchs as $match){
            // Joueurs du matchs
            $q->setTables('p2m');
            $q->addTable('i2p', 'p2m_pairid=i2p_pairid');
            $q->setFields('i2p_regiid');
            $q->setWhere('p2m_matchid=' . $match['mtch_id']);
            $regiIds = $q->getCol();
            $q->setTables('registration');
            $q->addValue('regi_court', $match['mtch_court']);
            $q->setWhere('regi_id IN(' . implode(',', $regiIds) . ')');
            $q->updateRow();

            // Arbitres
            $q->addValue('regi_court', -$match['mtch_court']);
            $q->setWhere('(regi_id=' . $match['mtch_umpireid'] . ' OR regi_id=' . $match['mtch_serviceid'] .')');
            $q->updateRow();
            $allregiIds = array_merge($allregiIds, $regiIds);
        }

        // Match des joueurs qui jouent, autre sur ceux en cours et terminé.
        $q->setTables('matchs');
        $q->addTable('p2m', 'p2m_matchid=mtch_id');
        $q->addTable('i2p', 'p2m_pairid=i2p_pairid');
        $q->addTable('ties', 'tie_id=mtch_tieid');
        $q->addField('mtch_id');
        $q->addWhere('mtch_status >' . CMATCH_STATUS_INCOMPLET);
        $q->addWhere('mtch_status <' . CMATCH_STATUS_LIVE);
        $q->addWhere('i2p_regiid IN (' . implode(',', $allregiIds) . ')');
        $q->addWhere("tie_place = '" . addslashes($aPlace) . "'");
        $matchIds = $q->getCol();

        if ( !empty($matchIds) ){
            $q->setTables('matchs');
            $q->setValue('mtch_status', CMATCH_STATUS_BUSY);
            $q->addWhere('mtch_id IN (' . implode(',', $matchIds) . ')');
            $q->updateRow();
        }
        return false;
    }

    function _badnetTeamResult($aNumMatch, $aBegin, $aEnd, $aScore, $aPosWinner=0){
        //ic::log("result : $aEventId, $aNumMatch, $aBegin, $aEnd, $aScore, $aPosWinner", 'svc');
        // Id du match
        $q = new icQuery('match', '_team');
        $q->setValue('mtch_begin', $aBegin);
        $q->addValue('mtch_end', $aEnd);
        $q->addValue('mtch_score', $aScore);
        $q->addWhere('mtch_id = '. $aNumMatch);

        if ( $aPosWinner != CMATCH_PAIR_TOP && $aPosWinner != CMATCH_PAIR_BOTTOM){
            $q->updateRow();
            return;
        }
        $q->addValue('mtch_status', CMATCH_STATUS_CLOSED);
        $ext = strtolower(substr(trim($aScore), -2));
        if ( $ext == 'ab' ){
            $winResult = CMATCH_RESULT_WINAB;
            $looseResult = CMATCH_RESULT_LOOSEAB;
        }
        if ( $ext == 'wo' ){
            $winResult = CMATCH_RESULT_WINWO;
            $looseResult = CMATCH_RESULT_LOOSEWO;
        }
        else{
            $winResult = CMATCH_RESULT_WIN;
            $looseResult = CMATCH_RESULT_LOOSE;
        }
        if( $aPosWinner == CMATCH_PAIR_TOP ){
            $q->addValue('mtch_resulth', $winResult);
            $q->addValue('mtch_resultv', $looseResult);
        }
        else{
            $q->addValue('mtch_resulth', $looseResult);
            $q->addValue('mtch_resultv', $winResult);
        }
        $q->updateRow();

        return false;
    }

    function currentId(){
        $date = getdate();
        $curSeason = $date['year']-2006;
        if ($date['mon'] >= 8) $curSeason++;
        return $curSeason;
    }

}

$server = new SoapServer(null, array(
		          'trace' => 1,
                  'cache_wsdl' => WSDL_CACHE_NONE,
				  'uri' => "http://www.badnet.org/"));
$server->setClass("Scorbad");
$server->handle();


?>