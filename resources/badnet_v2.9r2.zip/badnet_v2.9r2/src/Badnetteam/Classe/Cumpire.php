<?php

/**
 * Classe player
 */
class Cumpire{

	public function __construct($aUmpireId){
		$q = new Bn_query('umpire', '_team');
		$q->addField('*');
		$q->setWhere('umpi_id=' . $aUmpireId);
		$fields = $q->getRow();
		if (!empty($fields))
		{
			foreach($fields as $field =>$value)
			{
				$token = explode('_', $field);
				$this->setVal($token[1],  $value);
			}
		}
	}

    static public function lov(){
		$q = new Bn_query('umpire', '_team');
		$q->addField('umpi_id');
		$q->addField('umpi_famname');
		$q->addField('umpi_firstname');
        $q->setOrder('umpi_famname, umpi_firstname');
		$rows = $q->getRows();
        $umpires = array(-1 => 'Choisissez un arbitre');
        foreach($rows as $row){
            $umpires[$row['umpi_id']] = $row['umpi_famname'] . ' ' . $row['umpi_firstname'];
        }
        return $umpires;
    }

	public function setVal($aName, $aValue)
	{
		$this->_fields[$aName] = $aValue;
		return $aValue;
	}

	public function getVal($aName, $aDefault = null)
	{
		if ( isset($this->_fields[$aName]) ) $val = $this->_fields[$aName];
		else $val = $aDefault;
		return $val;
	}

	public function save()
	{
		// Recuperer les listes des champs de la table
		$q = new BN_query('umpire', '_team');
		$cols = $q->getColumnDef();

		// Filtrer les valeurs a mettre a jour
		foreach( $this->_fields as $key => $value)
		{
			if ( in_array('umpi_'.$key, $cols) )
			{
				$q->addValue('umpi_'.$key, $value);
			}
		}

		$q->setWhere('umpi_id=' . $this->getVal('id', -1));
		$id = $q->updateRow();
		return $id;
	}

}
?>