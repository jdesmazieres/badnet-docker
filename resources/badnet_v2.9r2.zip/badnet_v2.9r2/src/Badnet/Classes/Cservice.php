<?php
/*****************************************************************************
 !   $Id$
******************************************************************************/

class Cservice{
	private static $_location = "http://localhost:8093/src/Services/Scorbad.php";
	//private static $_location = "http://www.badnet.org/badnet/Src/Services/Allobad.php";
	private static $_uri = "http://test-uri/";

	/**
	* Recuperer un club a partir du numero
	*
	* @access public
	* @param  string   $aInstanceId Numero de departement
	* @param  integer   $aType Type des associations
	* @return void
	*/
	static public function getEvents($aDatabase=0){
bn::log('database='. $aDatabase);
bn::log(self::$_location);
		try {
			$client = new SoapClient(null,
			array(
					'location' => self::$_location,
					'uri'      => self::$_uri,
					'exceptions' => true,
					'trace' => 1,
		            'cache_wsdl' => WSDL_CACHE_NONE
			));
		}
		catch (Exception $e) {
			bn::log('getEvents:' .$e->getMessage());
			return null;
		}

		try {
			$response = $client->getEvents($aDatabase);
		}
		catch (Exception $e){
			Bn::log('retour getEvenwqwqts:' .$e->getMessage());
bn::log($client);
			return $client;
		}
		return($response);
	}


	/**
	* Recuperer un club a partir du numero
	*
	* @access public
	* @param  string   $aInstanceId Numero de departement
	* @param  integer   $aType Type des associations
	* @return void
	*/
	static public function getMatchs($aEventId, $aDatabase=0){
		try {
			$client = new SoapClient(null,
			array(
					'location' => self::$_location,
					'uri'      => self::$_uri,
					'exceptions' => true,
					'trace' => 1,
		            'cache_wsdl' => WSDL_CACHE_NONE
			));

		}
		catch (Exception $e) {
			Bn::log('getMatchs:' .$e->getMessage());
			return null;
		}

		try {
			$response = $client->getMatchs($aEventId, $aDatabase);
		}
		catch (Exception $e){
			Bn::log('retour getMatchs:' .$e->getMessage());
			return null;
		}
		return($response);
	}

	/**
	* Recuperer un club a partir du numero
	*
	* @access public
	* @param  string   $aInstanceId Numero de departement
	* @param  integer   $aType Type des associations
	* @return void
	*/
	static public function result($aEventId, $aNumMatch, $aBegin, $aEnd, $aScore, $aPosWinner=0, $aDatabase=0){
		try {
			$client = new SoapClient(null,
			array(
					'location' => self::$_location,
					'uri'      => self::$_uri,
					'exceptions' => true,
					'trace' => 1,
		            'cache_wsdl' => WSDL_CACHE_NONE
			));

		}
		catch (Exception $e) {
			Bn::log('result:' .$e->getMessage());
			return null;
		}

		try {
			$response = $client->result($aEventId, $aNumMatch, $aBegin, $aEnd, $aScore, $aPosWinner, $aDatabase);
		}
		catch (Exception $e){
			Bn::log('retour result:' .$e->getMessage());
			return null;
		}
		return($response);
	}
}
?>