function searchClub(sessionId, type, data)
{
 dpt = document.getElementById("k_assoDpt");
 type = document.getElementById("assoTypeSearch");
 if (type.value == 54)
   dpt.style.display = "block";
 else
   dpt.style.display = "none";
 return false;
}


  
