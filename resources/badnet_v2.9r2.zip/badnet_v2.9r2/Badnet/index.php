<?php
header("Location: ../src/index.php?theme=Badnet");
exit();
?>
