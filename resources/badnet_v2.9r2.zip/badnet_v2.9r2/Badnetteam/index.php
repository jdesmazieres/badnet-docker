<?php
header("Location: ../src/index.php?bnAction=262144&theme=Badnetteam");
exit();
?>
