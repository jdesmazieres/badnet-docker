<?php
header("Location: Badnet");
exit();
?>
